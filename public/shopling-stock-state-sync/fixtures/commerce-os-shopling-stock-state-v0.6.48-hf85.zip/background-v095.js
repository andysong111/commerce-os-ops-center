importScripts("background-v094.js");

// HF76 restores the proven price-resend bootstrap contract. A fresh exact A21
// worker must acknowledge the actual owner marker and the exact goods-key query
// after its content worker is ready. A plain "accepted" reply is never enough.
(() => {
  const VERSION_V095 = chrome.runtime.getManifest().version;
  const CANONICAL_SCRIPT_V095 = "content-a21-canonical-v019.js";
  const CANONICAL_VERSION_V095 = "0.1.9";
  const IDENTIFY_V095 = "A21_IDENTIFY";
  const ASSIGN_V095 = "A21_LIST_ASSIGNMENT";
  const BATCH_MAX_V095 = 200;
  const MANAGED_KEY_V095 = "commerceStockExecutionWorkerHf76";
  const WORKER_TIMEOUT_MS_V095 = 25_000;
  const POPUP_MATCH_HF81 = [
    "https://a.shopling.co.kr/prodlinkage/goods_mallMdfy_trsmt.phtml*",
    "https://kt.shopling.co.kr/prodlinkage/goods_mallMdfy_trsmt.phtml*",
  ];
  const RESULT_MATCH_V095 = [
    "https://shopling.co.kr/prod_a/prod_status_trsmt.phtml*",
    "https://*.shopling.co.kr/prod_a/prod_status_trsmt.phtml*",
  ];
  const legacyDispatchCurrentV095 = dispatchCurrent;
  const legacyDispatchToTargetV095 = dispatchToTarget;
  const normV095 = (value) => String(value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim();

  function groupedJobV095(active) {
    return Boolean(
      active?.status === "RUNNING" &&
      active?.stage === "A21_LIST" &&
      active?.job?.stockStateApiApplied === true &&
      Array.isArray(active?.job?.stockStateTransmissionGroupsHf72) &&
      active.job.stockStateTransmissionGroupsHf72.length > 0,
    );
  }

  function currentGroupV095(active) {
    const groups = active?.job?.stockStateTransmissionGroupsHf72;
    const index = Math.max(0, Number(active?.stockStateGroupIndexHf72 || 0));
    return Array.isArray(groups) ? groups[index] || null : null;
  }

  function currentBatchV095(active, group) {
    if (!group || !Array.isArray(group.goodsKeys)) return [];
    const start = Math.max(0, Number(active?.goodsKeyIndex || 0));
    const configured = Number(
      group.effectiveProductKind === "OPTION"
        ? active?.optionBatchLimit
        : active?.singleBatchLimit,
    );
    const limit = Math.max(
      1,
      Math.min(BATCH_MAX_V095, Number.isFinite(configured) ? configured : BATCH_MAX_V095),
    );
    return group.goodsKeys.slice(start, start + limit).map(normV095).filter(Boolean);
  }

  function prepareGroupedBatchV095(active) {
    const group = currentGroupV095(active);
    const batch = currentBatchV095(active, group);
    if (!group || !batch.length) return null;
    active.job.productKind = group.effectiveProductKind;
    active.job.goodsKeys = [...group.goodsKeys];
    active.job.currentTransmissionKind = group.transmissionKind;
    active.job.optionApiApplied = group.effectiveProductKind === "OPTION";
    active.job.productStatusApiApplied = group.effectiveProductKind === "SINGLE";
    active.job.currentGoodsOptionCount = Number(group.optionCounts?.[batch[0]] || 0);
    if (group.effectiveProductKind === "OPTION") {
      active.optionCurrentBatchKeys = [...batch];
      active.singleCurrentBatchKeys = [];
    } else {
      active.singleCurrentBatchKeys = [...batch];
      active.optionCurrentBatchKeys = [];
    }
    return { group, batch };
  }

  function runIdV095(active) {
    return String(active?.job?.executionId || active?.job?.jobId || "");
  }

  function executionOwnerV095(active) {
    const jobId = String(active?.job?.jobId || "");
    return `${jobId}:${runIdV095(active)}`;
  }

  function canonicalStageV095(active, group) {
    if (group.effectiveProductKind === "OPTION") {
      return String(
        active?.a21CanonicalStage ||
        `LIST_START_${Number(active?.stockStateGroupIndexHf72 || 0)}_${Number(active?.goodsKeyIndex || 0)}_${runIdV095(active)}`,
      );
    }
    return String(
      active?.singleA21CanonicalStage ||
      `SINGLE_LIST_START_${Number(active?.stockStateGroupIndexHf72 || 0)}_${Number(active?.goodsKeyIndex || 0)}_${runIdV095(active)}`,
    );
  }

  function canonicalAssignmentV095(active, group, batch) {
    return {
      type: ASSIGN_V095,
      jobId: active.job.jobId,
      mode: "OPTION",
      stockProductKindHf48: group.effectiveProductKind,
      goodsKeys: [...batch],
      stage: canonicalStageV095(active, group),
      runId: runIdV095(active),
      version: VERSION_V095,
    };
  }

  function assignmentOwnerKeyV095(assignment) {
    return [
      String(assignment?.jobId || ""),
      String(assignment?.runId || ""),
      String(assignment?.stockProductKindHf48 || ""),
      Array.isArray(assignment?.goodsKeys)
        ? assignment.goodsKeys.map(normV095).filter(Boolean).join(",")
        : "",
    ].join(":");
  }

  async function inspectExactA21TabV095(tabId) {
    if (!Number.isInteger(tabId)) return null;
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab) return null;
    const frames = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: () => {
        const norm = (value) => String(value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim();
        const compact = (value) => norm(value).replace(/\s+/g, "");
        const path = String(location.pathname || "").toLowerCase();
        const text = norm(document.body?.innerText || document.body?.textContent || document.documentElement?.innerText || "");
        const options = [...document.querySelectorAll("select option")].map((option) => compact(option.textContent));
        return {
          exactA21:
            path === "/prodlinkage/goods_prod_join_list.phtml" &&
            options.includes(compact("샵플링상품코드")) &&
            /쇼핑몰상품수정/i.test(text) &&
            /상품\s*수정전송/i.test(text),
          href: String(location.href || ""),
          title: String(document.title || ""),
        };
      },
    }).catch(() => []);
    const exact = frames.find((frame) => frame.result?.exactA21 === true);
    if (!exact) return null;
    return {
      tabId,
      windowId: tab.windowId,
      frameId: exact.frameId,
      role: "A21_LIST",
      owned: true,
      page: {
        role: "A21_LIST",
        href: String(exact.result.href || ""),
        title: String(exact.result.title || ""),
        canNavigate: false,
      },
    };
  }

  async function waitForExactA21WorkerV095(tabId, timeoutMs = WORKER_TIMEOUT_MS_V095) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const target = await inspectExactA21TabV095(tabId);
      if (target) return target;
      await sleep(180);
    }
    return null;
  }

  async function loadManagedWorkerV095() {
    const stored = await chrome.storage.local.get(MANAGED_KEY_V095).catch(() => ({}));
    return stored?.[MANAGED_KEY_V095] || null;
  }

  async function saveManagedWorkerV095(worker) {
    await chrome.storage.local.set({ [MANAGED_KEY_V095]: worker });
  }

  async function closePreviousManagedWorkerV095(ownerKey) {
    const previous = await loadManagedWorkerV095();
    if (!previous || previous.ownerKey === ownerKey || !Number.isInteger(previous.tabId)) return;
    const exact = await inspectExactA21TabV095(previous.tabId);
    if (exact) await chrome.tabs.remove(previous.tabId).catch(() => null);
  }

  async function ensureExecutionWorkerV095(active, templateTarget) {
    const ownerKey = executionOwnerV095(active);
    if (!ownerKey || ownerKey === ":") throw new Error("HF76_A21_EXECUTION_OWNER_MISSING");

    const bound = active?.a21ExecutionWorkerHf76;
    if (bound?.ownerKey === ownerKey && Number.isInteger(bound?.tabId)) {
      const exactBound = await waitForExactA21WorkerV095(bound.tabId, 6_000);
      if (exactBound) return { ...exactBound, ownerKey };
    }

    const exactTemplate = await inspectExactA21TabV095(templateTarget?.tabId);
    const href = String(exactTemplate?.page?.href || templateTarget?.page?.href || "");
    if (!exactTemplate || !href) throw new Error("HF76_EXACT_A21_TEMPLATE_NOT_FOUND");

    await closePreviousManagedWorkerV095(ownerKey);
    const created = await chrome.windows.create({
      url: href,
      type: "popup",
      width: 1420,
      height: 900,
      focused: false,
    });
    const createdTabId = created.tabs?.[0]?.id;
    if (!Number.isInteger(createdTabId)) throw new Error("HF76_FRESH_A21_WORKER_CREATE_FAILED");
    const target = await waitForExactA21WorkerV095(createdTabId);
    if (!target) {
      await chrome.tabs.remove(createdTabId).catch(() => null);
      throw new Error("HF76_FRESH_A21_WORKER_NOT_READY");
    }
    const managed = {
      ownerKey,
      tabId: target.tabId,
      windowId: target.windowId,
      frameId: target.frameId,
      createdAt: Date.now(),
      ownershipPolicy: "HF76_PREPARED_ACK_FRESH_A21_WORKER",
    };
    active.a21ExecutionWorkerHf76 = managed;
    active.workTabs = {
      ...(active.workTabs || {}),
      A21_LIST: { tabId: target.tabId, frameId: target.frameId },
    };
    await saveManagedWorkerV095(managed);
    await saveActive(active);
    return { ...target, ownerKey };
  }

  async function ensureCanonicalListWorkerV095(target) {
    if (!target || !Number.isInteger(target.tabId) || !Number.isInteger(target.frameId)) return false;
    const options = { frameId: target.frameId };
    const probe = async () => chrome.tabs.sendMessage(
      target.tabId,
      { type: IDENTIFY_V095 },
      options,
    ).catch(() => null);
    let result = await probe();
    if (result?.ok && result.role === "A21_LIST" && result.version === CANONICAL_VERSION_V095) return true;
    await chrome.scripting.executeScript({
      target: { tabId: target.tabId, frameIds: [target.frameId] },
      files: [CANONICAL_SCRIPT_V095],
    }).catch(() => null);
    for (let attempt = 0; attempt < 30; attempt += 1) {
      await sleep(160);
      result = await probe();
      if (result?.ok && result.role === "A21_LIST" && result.version === CANONICAL_VERSION_V095) return true;
    }
    return false;
  }

  async function bindAssignmentMarkerV095(target, assignment) {
    const marker = `commerce-os-a21-v016:${encodeURIComponent(JSON.stringify({
      jobId: String(assignment.jobId),
      mode: String(assignment.mode),
      runId: String(assignment.runId || ""),
      stage: String(assignment.stage || ""),
      stockProductKindHf48: String(assignment.stockProductKindHf48 || ""),
      goodsKeys: assignment.goodsKeys.map(normV095).filter(Boolean),
    }))}`;
    const results = await chrome.scripting.executeScript({
      target: { tabId: target.tabId, frameIds: [target.frameId] },
      world: "MAIN",
      func: (value) => {
        window.name = value;
        return String(window.name || "");
      },
      args: [marker],
    }).catch(() => []);
    return results.some((item) => item.result === marker);
  }

  async function ensureResultBaselineV095(active) {
    const batchKey = `${Number(active?.stockStateGroupIndexHf72 || 0)}:${Number(active?.goodsKeyIndex || 0)}`;
    if (active?.shoplingResultBaselineBatchKeyHf72 === batchKey) return;
    const tabs = await chrome.tabs.query({ url: RESULT_MATCH_V095 }).catch(() => []);
    active.shoplingResultBaselineBatchKeyHf72 = batchKey;
    active.shoplingResultBaselineTabIdsHf72 = tabs.map((tab) => Number(tab?.id)).filter(Number.isInteger);
  }

  async function armCurrentPopupOwnershipHf81(active, worker, assignment) {
    const tabs = await chrome.tabs.query({ url: POPUP_MATCH_HF81 }).catch(() => []);
    const baselineTabIds = tabs
      .map((tab) => Number(tab?.id))
      .filter(Number.isInteger);
    const listTabId = Number(worker?.tabId);
    const listWindowId = Number(worker?.windowId);
    const productKind = String(assignment?.stockProductKindHf48 || "");
    const goodsKeyQuery = Array.isArray(assignment?.goodsKeys)
      ? assignment.goodsKeys.map(normV095).filter(Boolean).join(",")
      : "";
    if (!Number.isInteger(listTabId) || !["OPTION", "SINGLE"].includes(productKind) || !goodsKeyQuery) {
      throw new Error("HF81_POPUP_OWNERSHIP_ARM_INVALID");
    }
    const binding = {
      ownerKey: String(worker?.ownerKey || ""),
      assignmentOwnerKey: assignmentOwnerKeyV095(assignment),
      listTabId,
      listWindowId: Number.isInteger(listWindowId) ? listWindowId : null,
      productKind,
      goodsKeyQuery,
      baselineTabIds,
      armedAt: Date.now(),
      claimedTabId: null,
    };
    active.a21PopupOwnershipHf81 = binding;
    active.a21PopupBaselineTabIds = [...baselineTabIds];
    active.singleA21PopupBaselineTabIds = [...baselineTabIds];
    active.a21ExpectedListTabId = listTabId;
    active.singleA21ExpectedListTabId = listTabId;
    return binding;
  }

  function preparedAckMatchesV095(response, assignment) {
    const query = assignment.goodsKeys.map(normV095).filter(Boolean).join(",");
    return Boolean(
      response?.ok === true &&
      response?.accepted === true &&
      response?.prepared === true &&
      response?.role === "A21_LIST" &&
      response?.version === CANONICAL_VERSION_V095 &&
      response?.ownerKey === assignmentOwnerKeyV095(assignment) &&
      response?.goodsKeyQuery === query &&
      Number(response?.goodsKeyCount) === assignment.goodsKeys.length,
    );
  }

  async function dispatchPreparedGroupedV095(active, templateTarget, { focus = false } = {}) {
    const prepared = prepareGroupedBatchV095(active);
    if (!prepared) return false;
    const { group, batch } = prepared;
    const worker = await ensureExecutionWorkerV095(active, templateTarget);
    if (focus) {
      await chrome.tabs.update(worker.tabId, { active: true }).catch(() => null);
      if (Number.isInteger(worker.windowId)) {
        await chrome.windows.update(worker.windowId, { focused: true }).catch(() => null);
      }
    }
    if (!(await ensureCanonicalListWorkerV095(worker))) {
      await progress(active, `${active.job.barcode} · 전용 A21 본문 작업기가 준비되지 않아 전송 차단`, {
        code: "SHOPLING_HF76_CANONICAL_WORKER_NOT_READY",
        target: worker,
        goodsKeys: batch,
      });
      return false;
    }

    active.shoplingTabId = worker.tabId;
    active.shoplingFrameId = worker.frameId;
    active.workTabs = {
      ...(active.workTabs || {}),
      A21_LIST: { tabId: worker.tabId, frameId: worker.frameId },
    };
    await ensureResultBaselineV095(active);
    const assignment = canonicalAssignmentV095(active, group, batch);
    await armCurrentPopupOwnershipHf81(active, worker, assignment);
    await saveActive(active);
    if (!(await bindAssignmentMarkerV095(worker, assignment))) {
      await progress(active, `${active.job.barcode} · 전용 A21 작업창 소유권 기록 실패`, {
        code: "SHOPLING_HF76_OWNER_MARKER_WRITE_FAILED",
        goodsKeys: batch,
      });
      return false;
    }

    let response = null;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      response = await chrome.tabs.sendMessage(
        worker.tabId,
        assignment,
        { frameId: worker.frameId },
      ).catch(() => null);
      if (preparedAckMatchesV095(response, assignment)) break;
      await sleep(220);
    }
    if (!preparedAckMatchesV095(response, assignment)) {
      await progress(active, `${active.job.barcode} · A21이 명령만 받았을 뿐 실제 goods key 입력 준비를 증명하지 못해 전송 차단`, {
        code: "SHOPLING_HF76_PREPARED_ACK_MISSING",
        expectedOwnerKey: assignmentOwnerKeyV095(assignment),
        expectedGoodsKeyQuery: batch.join(","),
        response,
      });
      return false;
    }

    await progress(
      active,
      `${active.job.barcode} · ${group.effectiveProductKind === "OPTION" ? "옵션송신" : "상품판매상태송신"} goods key ${batch.length}건 입력·소유권 확인 후 A21 실행`,
      {
        transmissionKind: group.transmissionKind,
        groupedGoodsKeys: batch,
        groupedGoodsKeyCount: batch.length,
        preparedAck: true,
        preparedOwnerKey: response.ownerKey,
        preparedGoodsKeyQuery: response.goodsKeyQuery,
        serialPerGoodsKey: false,
        extensionVersion: VERSION_V095,
      },
    );
    return true;
  }

  if (globalThis.__COMMERCE_OS_EXPOSE_STOCK_HF76_TEST_HOOKS__ === true) {
    globalThis.__commerceOsStockHf76TestHooks = {
      groupedJobV095,
      currentBatchV095,
      prepareGroupedBatchV095,
      canonicalAssignmentV095,
      assignmentOwnerKeyV095,
      preparedAckMatchesV095,
      ensureExecutionWorkerV095,
      ensureCanonicalListWorkerV095,
      armCurrentPopupOwnershipHf81,
    };
    return;
  }

  dispatchToTarget = async function dispatchToTargetV095(active, target) {
    if (!groupedJobV095(active)) return legacyDispatchToTargetV095(active, target);
    return dispatchPreparedGroupedV095(active, target);
  };

  dispatchCurrent = async function dispatchCurrentV095(active, options = {}) {
    if (!groupedJobV095(active)) return legacyDispatchCurrentV095(active, options);
    const boundTabId = active?.a21ExecutionWorkerHf76?.tabId;
    const template = Number.isInteger(boundTabId)
      ? await waitForExactA21WorkerV095(boundTabId, 6_000)
      : await findExactRoleTarget("A21_LIST");
    if (!template) return false;
    return dispatchPreparedGroupedV095(active, template, options);
  };

  console.log(
    "[CommerceOS Stock HF76]",
    new Date().toISOString(),
    "fresh A21 worker accepts only after exact goods-key query and stable execution ownership are prepared",
    VERSION_V095,
  );
})();


// COMMERCE_OS_STOCK_HF82_DIRECT_LAST_MILE
(() => {
  const VERSION_HF82 = chrome.runtime.getManifest().version;
  const POPUP_PATH_HF82 = "/prodlinkage/goods_mallMdfy_trsmt.phtml";
  const inFlightHf82 = new Set();
  const executeLastMileHf82 = async function i(e){let t=e=>new Promise(t=>setTimeout(t,e)),n=e=>String(e??"").normalize("NFKC").replace(/\s+/g," ").trim(),i=e=>{if(!(e instanceof HTMLElement))return!1;let t=getComputedStyle(e);return"none"!==t.display&&"hidden"!==t.visibility&&e.getClientRects().length>0},r=e=>[...new Set([e.closest("label")?.textContent,e.closest("td")?.textContent,e.parentElement?.textContent,e.previousElementSibling?.textContent,e.nextElementSibling?.textContent].map(n).filter(Boolean))],a=e=>{let t=[...document.querySelectorAll('input[type="radio"]')].filter(i).filter(t=>r(t).includes(e));return 1===t.length?t[0]:null},o=(e,t)=>{let n=[...document.querySelectorAll('input[type="radio"]')].filter(n=>n.name===e&&String(n.value)===t);return 1===n.length?n[0]:null},s=e=>{let t=[...document.querySelectorAll("tr")].filter(i).filter(t=>[...t.querySelectorAll(":scope > th, :scope > td")].some(t=>n(t.textContent)===e)).flatMap(e=>[...e.querySelectorAll('input[type="radio"]')].filter(i).filter(e=>r(e).includes("선택")));return 1===t.length?t[0]:null},c=e=>{if(!e||!i(e))return!1;if(e.checked||HTMLInputElement.prototype.click.call(e),!e.checked){let t=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"checked");t?.set?.call(e,!0),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}return!0===e.checked},d=()=>{let e=[...document.querySelectorAll("input, button, a")].filter(i).filter(e=>"상품수정 송신"===n(e instanceof HTMLInputElement?e.value:e.textContent));return 1===e.length?e[0]:null},l=()=>[...document.querySelectorAll('input[type="hidden"]')].filter(e=>"prod_join_chk[]"===e.name).map(e=>String(e.value??"")),u=n(e?.productKind).toUpperCase(),p=n(e?.desiredStatus).toUpperCase(),b="OPTION"===u?"옵션송신":"상품판매상태송신",_="OPTION"===u?"옵션송신":["SOLD_OUT","OUT_OF_STOCK"].includes(p)?"품절":"ON_SALE"===p?"판매중":"";if(!["OPTION","SINGLE"].includes(u)||!_)return{ok:!1,code:"HF82_LAST_MILE_INPUT_INVALID"};let g=n(e?.receiptKey),f=document.documentElement.dataset.commerceOsHf82Commit||"";if(g&&f===g)return{ok:!0,duplicate:!0,receiptKey:g,productKind:u,desiredStatus:p,topLabel:b,targetLabel:_,topChecked:!0,targetChecked:!0,submitClicked:!0};let m=Math.max(1,Math.min(40,Number(e?.maxAttempts)||40));for(let e=0;e<m;e+=1){let e="OPTION"===u&&o("modify_tp","goods_stock")||a(b);if(e){let i=c(e);await t(180);let r=c("OPTION"===u&&o("trsmt_env_mody_opt","1")||s(_));await t(180);let f="OPTION"===u&&o("modify_tp","goods_stock")||a(b),m="OPTION"===u&&o("trsmt_env_mody_opt","1")||s(_);if(!i||!r||!f?.checked||!m?.checked)return{ok:!1,code:"HF82_EXACT_RADIO_READBACK_FAILED",topLabel:b,targetLabel:_,topChecked:f?.checked===!0,targetChecked:m?.checked===!0};let I=l();if(!I.length||I.some(e=>!/^\d+$/.test(e)))return{ok:!1,code:"HF82_EXACT_PAYLOAD_INVALID",payloadCount:I.length};let h=d();if(!h)return{ok:!1,code:"HF82_EXACT_SUBMIT_NOT_FOUND"};if(await t(350),!f.checked||!m.checked)return{ok:!1,code:"HF82_RADIO_CHANGED_BEFORE_SUBMIT"};let T=window,S=T.goods_mallMdfy_submit_sp,y=T.confirm,O=!1,w=!1;if("function"!=typeof S)return{ok:!1,code:"HF82_SHOPLING_SUBMIT_FUNCTION_MISSING"};T.goods_mallMdfy_submit_sp=()=>(O=!0,S.call(T)),T.confirm=e=>{let t=n(e);return/수정전송\s*할\s*상품을\s*선택하셨습니까/.test(t)?(w=!0,!0):y.call(T,e)};try{HTMLElement.prototype.click.call(h)}finally{T.confirm=y,T.goods_mallMdfy_submit_sp=S}if(!O)return{ok:!1,code:"HF82_SHOPLING_SUBMIT_FUNCTION_NOT_INVOKED"};return g&&(document.documentElement.dataset.commerceOsHf82Commit=g),{ok:!0,receiptKey:g,productKind:u,desiredStatus:p,topLabel:b,targetLabel:_,topChecked:!0===f.checked,targetChecked:!0===m.checked,submitClicked:!0,shoplingSubmitInvoked:O,submitConfirmSeen:w,payloadCount:I.length,clickedAt:Date.now()}}await t(100)}return{ok:!1,code:"HF82_EXACT_LAST_MILE_CONTROLS_NOT_FOUND",topLabel:b,targetLabel:_}};

  function normHf82(value) {
    return String(value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim();
  }

  function exactPopupUrlHf82(value) {
    try {
      const url = new URL(String(value || ""));
      return ["a.shopling.co.kr", "kt.shopling.co.kr"].includes(url.hostname)
        && url.pathname === POPUP_PATH_HF82;
    } catch {
      return false;
    }
  }

  function batchQueryHf82(active) {
    const option = String(active?.job?.productKind || "").toUpperCase() === "OPTION";
    const values = option
      ? active?.optionCurrentBatchKeys
      : active?.singleCurrentBatchKeys;
    return (Array.isArray(values) ? values : active?.job?.goodsKeys || [])
      .map(normHf82)
      .filter(Boolean)
      .join(",");
  }

  function bindingMatchesHf82(active, tabId) {
    const binding = active?.a21PopupOwnershipHf81;
    const productKind = String(active?.job?.productKind || "").toUpperCase();
    const goodsKeyQuery = batchQueryHf82(active);
    const runId = String(active?.job?.executionId || active?.job?.jobId || "");
    const ownerKey = [
      String(active?.job?.jobId || ""),
      runId,
      productKind,
      goodsKeyQuery,
    ].join(":");
    if (!binding || !["OPTION", "SINGLE"].includes(productKind) || !goodsKeyQuery) {
      return false;
    }
    if (binding.productKind !== productKind || binding.goodsKeyQuery !== goodsKeyQuery) {
      return false;
    }
    if (binding.assignmentOwnerKey !== ownerKey) return false;
    const baseline = new Set(
      (binding.baselineTabIds || []).map(Number).filter(Number.isInteger),
    );
    if (baseline.has(tabId)) return false;
    const claimed = binding.claimedTabId == null
      ? null
      : Number(binding.claimedTabId);
    return !Number.isInteger(claimed) || claimed === tabId;
  }

  function receiptKeyHf82(active) {
    return [
      String(active?.job?.jobId || ""),
      String(active?.job?.executionId || active?.job?.jobId || ""),
      String(active?.job?.productKind || "").toUpperCase(),
      batchQueryHf82(active),
    ].join(":");
  }

  async function directLastMileHf82(tabId, tabUrl) {
    if (
      !Number.isInteger(tabId)
      || !exactPopupUrlHf82(tabUrl)
      || inFlightHf82.has(tabId)
    ) {
      return;
    }
    inFlightHf82.add(tabId);
    try {
      const active = await loadActive();
      if (
        !active
        || active.status !== "RUNNING"
        || !["A21_LIST", "A21_POPUP"].includes(String(active.stage || ""))
      ) {
        return;
      }
      if (!bindingMatchesHf82(active, tabId)) return;
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      if (!tab || !exactPopupUrlHf82(tab.url || tab.pendingUrl)) return;

      const binding = active.a21PopupOwnershipHf81;
      binding.claimedTabId = tabId;
      binding.claimedAt = Date.now();
      active.stage = "A21_POPUP";
      active.stageStartedAt = Date.now();
      active.workTabs = {
        ...(active.workTabs || {}),
        A21_POPUP: { tabId, frameId: 0 },
      };
      active.shoplingTabId = tabId;
      active.shoplingFrameId = 0;
      if (String(active.job?.productKind || "").toUpperCase() === "SINGLE") {
        active.singlePopupTabId = tabId;
        active.singlePopupWindowId = tab.windowId ?? null;
      }
      await saveActive(active);

      const key = receiptKeyHf82(active);
      const injected = await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: executeLastMileHf82,
        args: [{
          productKind: active.job.productKind,
          desiredStatus: active.job.desiredStatus,
          receiptKey: key,
        }],
      }).catch(() => []);
      const receipt = injected
        .map((item) => item?.result)
        .find((item) => item?.receiptKey === key) || null;
      if (
        !receipt?.ok
        || receipt?.submitClicked !== true
        || receipt?.shoplingSubmitInvoked !== true
        || receipt?.topChecked !== true
        || receipt?.targetChecked !== true
      ) {
        await finish(
          active,
          "FAILED",
          String(active.job.barcode || "") + " · Shopling 파란 라디오 선택 또는 상품수정 송신 클릭을 증명하지 못했습니다.",
          {
            code: receipt?.code || "SHOPLING_HF82_LAST_MILE_RECEIPT_MISSING",
            popupTabId: tabId,
            receipt,
            retrySafe: true,
            externalWriteConfirmed: false,
          },
        );
        return;
      }

      active.lastMileReceiptHf82 = {
        ...receipt,
        popupTabId: tabId,
        goodsKeyQuery: batchQueryHf82(active),
        assignmentOwnerKey: binding.assignmentOwnerKey,
        recordedAt: Date.now(),
      };
      active.stage = "WAIT_A21_RESULT";
      active.stageStartedAt = Date.now();
      await saveActive(active);
      await progress(
        active,
        String(active.job.barcode || "") + " · " + receipt.topLabel + " → " + receipt.targetLabel + " 파란 라디오 확인 · 상품수정 송신 클릭 완료",
        {
          code: "SHOPLING_HF82_LAST_MILE_COMMITTED",
          lastMileReceipt: active.lastMileReceiptHf82,
          extensionVersion: VERSION_HF82,
        },
      );
    } finally {
      inFlightHf82.delete(tabId);
    }
  }

  function scheduleHf82(tabId, tabUrl) { void tabId; void tabUrl; }

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const href = String(tab?.url || tab?.pendingUrl || "");
    if (changeInfo.status === "complete") scheduleHf82(tabId, href);
  });
  chrome.tabs.onCreated.addListener((tab) => {
    const tabId = Number(tab?.id);
    if (!Number.isInteger(tabId)) return;
    setTimeout(async () => {
      const current = await chrome.tabs.get(tabId).catch(() => null);
      scheduleHf82(
        tabId,
        String(current?.url || current?.pendingUrl || ""),
      );
    }, 350);
  });

  if (globalThis.__COMMERCE_OS_EXPOSE_STOCK_HF82_TEST_HOOKS__ === true) {
    globalThis.__commerceOsStockHf82TestHooks = {
      exactPopupUrlHf82,
      batchQueryHf82,
      bindingMatchesHf82,
      receiptKeyHf82,
      directLastMileHf82,
    };
  }

  console.log(
    "[CommerceOS Stock HF82]",
    new Date().toISOString(),
    "direct MAIN-world radio selection and submit click",
    VERSION_HF82,
  );
})();


// COMMERCE_OS_STOCK_HF83_PROBE_THEN_COMMIT
(() => {
  const VERSION_HF83 = chrome.runtime.getManifest().version;
  const POPUP_PATH_HF83 = "/prodlinkage/goods_mallMdfy_trsmt.phtml";
  const POPUP_URLS_HF83 = [
    "https://a.shopling.co.kr/prodlinkage/goods_mallMdfy_trsmt.phtml*",
    "https://kt.shopling.co.kr/prodlinkage/goods_mallMdfy_trsmt.phtml*",
  ];
  const READY_TIMEOUT_MS_HF83 = 15000;
  const inFlightHf83 = new Set();
  const readinessHf83 = new Map();
  const committedHf83 = new Set();
  const probeLastMileHf83 = function i(e){let t=e=>String(e??"").normalize("NFKC").replace(/\s+/g," ").trim(),n=e=>{if(!(e instanceof HTMLElement))return!1;let t=getComputedStyle(e);return"none"!==t.display&&"hidden"!==t.visibility&&e.getClientRects().length>0},i=()=>[...document.querySelectorAll('input[type="radio"]')].filter(n).filter(e=>!e.disabled).map((e,n)=>{let i=e.getBoundingClientRect();return{radio:e,index:n,top:Math.round(Number(i.top)||0),left:Math.round(Number(i.left)||0),inlineTexts:(e=>{let n=[];if(e.id)for(let t of document.querySelectorAll("label"))t.htmlFor===e.id&&n.push(t.textContent);for(let t of(n.push(e.closest("label")?.textContent),[e.previousSibling,e.nextSibling,e.previousElementSibling,e.nextElementSibling]))n.push(t?.textContent||t?.nodeValue);return[...new Set(n.map(t).filter(Boolean))].slice(0,8)})(e),cellText:t(e.closest("td,th")?.textContent).slice(0,120),name:String(e.name||"").slice(0,80),value:String(e.value||"").slice(0,80)}}),r=(e,t)=>[...document.querySelectorAll('input[type="radio"]')].filter(n).filter(e=>!e.disabled).filter(n=>n.name===e&&String(n.value)===t),o=[...document.querySelectorAll("input, button, a")].filter(n).filter(e=>"상품수정 송신"===t(e instanceof HTMLInputElement?e.value:e.textContent)),a=[...document.querySelectorAll('input[type="hidden"]')].filter(e=>"prod_join_chk[]"===e.name).map(e=>String(e.value??"")),l=t(e?.productKind).toUpperCase(),s=t(e?.desiredStatus).toUpperCase(),c="OPTION"===l?"옵션송신":"상품판매상태송신",d="OPTION"===l?"옵션송신":["SOLD_OUT","OUT_OF_STOCK"].includes(s)?"품절":"ON_SALE"===s?"판매중":"";if(!["OPTION","SINGLE"].includes(l)||!d)return{eligible:!1,code:"HF83_PROBE_INPUT_INVALID"};let u="OPTION"===l?r("modify_tp","goods_stock"):[],f="OPTION"===l?r("trsmt_env_mody_opt","1"):[],p=u.length?u:(e=>{let t=i(),n=t.filter(t=>t.inlineTexts.includes(e));if(1===n.length)return[n[0].radio];if(n.length>1||t.length<3)return[];let r=[...t].sort((e,t)=>e.top-t.top||e.left-t.left),o=r.filter(e=>8>=Math.abs(e.top-r[0].top)).sort((e,t)=>e.left-t.left),a=["일반내용수정","상품판매상태송신","옵션송신"];if(3!==o.length||!o.every((e,t)=>e.inlineTexts.includes(a[t])||e.cellText.startsWith(a[t])))return[];let l=a.indexOf(e);return l>=0?[o[l].radio]:[]})(c),m=f.length?f:[...document.querySelectorAll("tr")].filter(n).filter(e=>[...e.querySelectorAll(":scope > th, :scope > td")].some(e=>t(e.textContent)===d)).flatMap(e=>[...e.querySelectorAll('input[type="radio"]')].filter(n).filter(e=>[e.closest("label")?.textContent,e.closest("td")?.textContent,e.parentElement?.textContent,e.previousElementSibling?.textContent,e.nextElementSibling?.textContent].map(t).filter(Boolean).includes("선택"))),_=a.length>0&&a.every(e=>/^\d+$/.test(e)),h="function"==typeof window.goods_mallMdfy_submit_sp,b=1===p.length&&1===m.length&&p[0]!==m[0]&&1===o.length&&_&&h;return{eligible:b,code:b?"HF83_PROBE_READY":"HF83_PROBE_NOT_READY",productKind:l,desiredStatus:s,topLabel:c,targetLabel:d,topCount:p.length,targetCount:m.length,submitCount:o.length,payloadCount:a.length,payloadValid:_,submitFunctionReady:h,modeDiagnostics:i().slice(0,12).map(e=>({index:e.index,top:e.top,left:e.left,name:e.name,value:e.value,inlineTexts:e.inlineTexts.map(e=>String(e).slice(0,120)),cellText:e.cellText})),pathname:String(window.location?.pathname||"")}};
  const commitLastMileHf83 = async function r(e){let t=e=>new Promise(t=>setTimeout(t,e)),n=e=>String(e??"").normalize("NFKC").replace(/\s+/g," ").trim(),i=e=>{if(!(e instanceof HTMLElement))return!1;let t=getComputedStyle(e);return"none"!==t.display&&"hidden"!==t.visibility&&e.getClientRects().length>0},r=e=>{let t=[...document.querySelectorAll('input[type="radio"]')].filter(i).filter(e=>!e.disabled).map((e,t)=>{let i=e.getBoundingClientRect();return{radio:e,index:t,top:Math.round(Number(i.top)||0),left:Math.round(Number(i.left)||0),inlineTexts:(e=>{let t=[];if(e.id)for(let n of document.querySelectorAll("label"))n.htmlFor===e.id&&t.push(n.textContent);for(let n of(t.push(e.closest("label")?.textContent),[e.previousSibling,e.nextSibling,e.previousElementSibling,e.nextElementSibling]))t.push(n?.textContent||n?.nodeValue);return[...new Set(t.map(n).filter(Boolean))].slice(0,8)})(e),cellText:n(e.closest("td,th")?.textContent).slice(0,120)}}),r=t.filter(t=>t.inlineTexts.includes(e));if(1===r.length)return r[0].radio;if(r.length>1||t.length<3)return null;let o=[...t].sort((e,t)=>e.top-t.top||e.left-t.left),a=o.filter(e=>8>=Math.abs(e.top-o[0].top)).sort((e,t)=>e.left-t.left),l=["일반내용수정","상품판매상태송신","옵션송신"];if(3!==a.length||!a.every((e,t)=>e.inlineTexts.includes(l[t])||e.cellText.startsWith(l[t])))return null;let s=l.indexOf(e);return s>=0?a[s].radio:null},o=(e,t)=>{let n=[...document.querySelectorAll('input[type="radio"]')].filter(i).filter(e=>!e.disabled).filter(n=>n.name===e&&String(n.value)===t);return 1===n.length?n[0]:null},a=e=>{let t=[...document.querySelectorAll("tr")].filter(i).filter(t=>[...t.querySelectorAll(":scope > th, :scope > td")].some(t=>n(t.textContent)===e)).flatMap(e=>[...e.querySelectorAll('input[type="radio"]')].filter(i).filter(e=>[e.closest("label")?.textContent,e.closest("td")?.textContent,e.parentElement?.textContent,e.previousElementSibling?.textContent,e.nextElementSibling?.textContent].map(n).filter(Boolean).includes("선택")));return 1===t.length?t[0]:null},l=e=>{if(!e||!i(e))return!1;if(e.checked||HTMLInputElement.prototype.click.call(e),!e.checked){let t=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"checked");t?.set?.call(e,!0),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}return!0===e.checked},s=n(e?.productKind).toUpperCase(),c=n(e?.desiredStatus).toUpperCase(),d="OPTION"===s?"옵션송신":"상품판매상태송신",u="OPTION"===s?"옵션송신":["SOLD_OUT","OUT_OF_STOCK"].includes(c)?"품절":"ON_SALE"===c?"판매중":"";if(!["OPTION","SINGLE"].includes(s)||!u)return{ok:!1,code:"HF83_COMMIT_INPUT_INVALID"};let f=n(e?.receiptKey);if(f&&document.documentElement.dataset.commerceOsHf83Commit===f)return{ok:!0,duplicate:!0,receiptKey:f,productKind:s,desiredStatus:c,topLabel:d,targetLabel:u,topChecked:!0,targetChecked:!0,shoplingSubmitInvoked:!0,submitDispatchMethod:"ORIGINAL_SHOPLING_FUNCTION"};if(!l("OPTION"===s&&o("modify_tp","goods_stock")||r(d)))return{ok:!1,code:"HF83_TOP_RADIO_CHECK_FAILED",topLabel:d};if(await t(180),!l("OPTION"===s&&o("trsmt_env_mody_opt","1")||a(u)))return{ok:!1,code:"HF83_TARGET_RADIO_CHECK_FAILED",targetLabel:u};await t(180);let p="OPTION"===s&&o("modify_tp","goods_stock")||r(d),m="OPTION"===s&&o("trsmt_env_mody_opt","1")||a(u);if(!p?.checked||!m?.checked)return{ok:!1,code:"HF83_EXACT_RADIO_READBACK_FAILED",topChecked:p?.checked===!0,targetChecked:m?.checked===!0};let _=[...document.querySelectorAll('input[type="hidden"]')].filter(e=>"prod_join_chk[]"===e.name).map(e=>String(e.value??""));if(!_.length||_.some(e=>!/^\d+$/.test(e)))return{ok:!1,code:"HF83_EXACT_PAYLOAD_INVALID",payloadCount:_.length};if(1!==[...document.querySelectorAll("input, button, a")].filter(i).filter(e=>"상품수정 송신"===n(e instanceof HTMLInputElement?e.value:e.textContent)).length)return{ok:!1,code:"HF83_EXACT_SUBMIT_CONTROL_INVALID"};let h=window,b=h.goods_mallMdfy_submit_sp,g=h.confirm;if("function"!=typeof b)return{ok:!1,code:"HF83_SHOPLING_SUBMIT_FUNCTION_MISSING"};let I=!1,S="";h.confirm=e=>{let t=n(e);return/수정전송\s*할\s*상품을\s*선택하셨습니까/.test(t)?(I=!0,!0):(S=t.slice(0,240),!1)};try{b.call(h)}catch(e){return{ok:!1,code:"HF83_SHOPLING_SUBMIT_FUNCTION_THROWN",error:e instanceof Error?e.message:String(e)}}finally{h.confirm=g}return S?{ok:!1,code:"HF83_UNEXPECTED_CONFIRM_BLOCKED",unexpectedConfirm:S}:(f&&(document.documentElement.dataset.commerceOsHf83Commit=f),{ok:!0,receiptKey:f,productKind:s,desiredStatus:c,topLabel:d,targetLabel:u,topChecked:!0,targetChecked:!0,shoplingSubmitInvoked:!0,submitConfirmSeen:I,submitControlVerified:!0,submitDispatchMethod:"ORIGINAL_SHOPLING_FUNCTION",payloadCount:_.length,invokedAt:Date.now()})};

  function normHf83(value) {
    return String(value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim();
  }

  function exactPopupUrlHf83(value) {
    try {
      const url = new URL(String(value || ""));
      return ["a.shopling.co.kr", "kt.shopling.co.kr"].includes(url.hostname)
        && url.pathname === POPUP_PATH_HF83;
    } catch {
      return false;
    }
  }

  function batchQueryHf83(active) {
    const option = String(active?.job?.productKind || "").toUpperCase() === "OPTION";
    const values = option ? active?.optionCurrentBatchKeys : active?.singleCurrentBatchKeys;
    return (Array.isArray(values) ? values : active?.job?.goodsKeys || [])
      .map(normHf83)
      .filter(Boolean)
      .join(",");
  }

  function receiptKeyHf83(active) {
    return [
      String(active?.job?.jobId || ""),
      String(active?.job?.executionId || active?.job?.jobId || ""),
      String(active?.job?.productKind || "").toUpperCase(),
      batchQueryHf83(active),
    ].join(":");
  }

  function bindingMatchesHf83(active, tabId) {
    const binding = active?.a21PopupOwnershipHf81;
    const productKind = String(active?.job?.productKind || "").toUpperCase();
    const goodsKeyQuery = batchQueryHf83(active);
    const runId = String(active?.job?.executionId || active?.job?.jobId || "");
    const ownerKey = [String(active?.job?.jobId || ""), runId, productKind, goodsKeyQuery].join(":");
    if (!binding || !["OPTION", "SINGLE"].includes(productKind) || !goodsKeyQuery) return false;
    if (binding.productKind !== productKind || binding.goodsKeyQuery !== goodsKeyQuery) return false;
    if (binding.assignmentOwnerKey !== ownerKey) return false;
    const baseline = new Set((binding.baselineTabIds || []).map(Number).filter(Number.isInteger));
    if (baseline.has(tabId)) return false;
    const claimed = binding.claimedTabId == null ? null : Number(binding.claimedTabId);
    return !Number.isInteger(claimed) || claimed === tabId;
  }

  async function probeTabHf83(tab, active) {
    const tabId = Number(tab?.id);
    if (!Number.isInteger(tabId) || !bindingMatchesHf83(active, tabId)) return [];
    const injected = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      world: "MAIN",
      func: probeLastMileHf83,
      args: [{
        productKind: active.job.productKind,
        desiredStatus: active.job.desiredStatus,
      }],
    }).catch(() => []);
    return injected.map((item) => ({
      tabId,
      frameId: Number(item?.frameId),
      result: item?.result || null,
    }));
  }

  async function scanOwnedFramesHf83(active) {
    const tabs = await chrome.tabs.query({ url: POPUP_URLS_HF83 }).catch(() => []);
    const candidates = tabs.filter((tab) => Number.isInteger(tab?.id)
      && exactPopupUrlHf83(tab.url || tab.pendingUrl)
      && bindingMatchesHf83(active, Number(tab.id)));
    const rows = [];
    for (const tab of candidates) rows.push(...await probeTabHf83(tab, active));
    return {
      candidates,
      rows,
      eligible: rows.filter((row) => row.result?.eligible === true),
    };
  }

  async function failAfterReadinessTimeoutHf83(active, key, scan) {
    readinessHf83.delete(key);
    await finish(
      active,
      "FAILED",
      String(active.job?.barcode || "") + " · Shopling 파란 라디오가 있는 단 하나의 실행 프레임을 15초 안에 확인하지 못했습니다.",
      {
        code: scan.eligible.length > 1
          ? "SHOPLING_HF83_AMBIGUOUS_READY_FRAMES"
          : "SHOPLING_HF83_READY_FRAME_TIMEOUT",
        candidateTabIds: scan.candidates.map((tab) => Number(tab.id)),
        frameDiagnostics: scan.rows.map((row) => ({
          tabId: row.tabId,
          frameId: row.frameId,
          result: row.result,
        })),
        retrySafe: true,
        externalWriteConfirmed: false,
      },
    );
  }

  async function probeThenCommitHf83() {
    const active = await loadActive();
    if (!active || active.status !== "RUNNING"
      || !["A21_LIST", "A21_POPUP"].includes(String(active.stage || ""))) return;
    const key = receiptKeyHf83(active);
    if (!key || committedHf83.has(key) || inFlightHf83.has(key)) return;
    inFlightHf83.add(key);
    try {
      const current = readinessHf83.get(key) || { startedAt: Date.now(), attempts: 0 };
      current.attempts += 1;
      readinessHf83.set(key, current);
      const scan = await scanOwnedFramesHf83(active);
      if (scan.eligible.length !== 1) {
        if (Date.now() - current.startedAt < READY_TIMEOUT_MS_HF83) {
          setTimeout(() => void probeThenCommitHf83(), 300);
          return;
        }
        await failAfterReadinessTimeoutHf83(active, key, scan);
        return;
      }

      const chosen = scan.eligible[0];
      const latest = await loadActive();
      if (!latest || latest.status !== "RUNNING" || receiptKeyHf83(latest) !== key
        || !bindingMatchesHf83(latest, chosen.tabId)) return;
      const binding = latest.a21PopupOwnershipHf81;
      binding.claimedTabId = chosen.tabId;
      binding.claimedFrameId = chosen.frameId;
      binding.claimedAt = Date.now();
      latest.stage = "A21_POPUP";
      latest.stageStartedAt = Date.now();
      latest.workTabs = {
        ...(latest.workTabs || {}),
        A21_POPUP: { tabId: chosen.tabId, frameId: chosen.frameId },
      };
      latest.shoplingTabId = chosen.tabId;
      latest.shoplingFrameId = chosen.frameId;
      if (String(latest.job?.productKind || "").toUpperCase() === "SINGLE") {
        latest.singlePopupTabId = chosen.tabId;
      }
      await saveActive(latest);

      const injected = await chrome.scripting.executeScript({
        target: { tabId: chosen.tabId, frameIds: [chosen.frameId] },
        world: "MAIN",
        func: commitLastMileHf83,
        args: [{
          productKind: latest.job.productKind,
          desiredStatus: latest.job.desiredStatus,
          receiptKey: key,
        }],
      }).catch(() => []);
      const receipt = injected.map((item) => item?.result)
        .find((item) => item?.receiptKey === key) || null;
      if (!receipt?.ok || receipt?.shoplingSubmitInvoked !== true
        || receipt?.topChecked !== true || receipt?.targetChecked !== true
        || receipt?.submitDispatchMethod !== "ORIGINAL_SHOPLING_FUNCTION") {
        await finish(
          latest,
          "FAILED",
          String(latest.job?.barcode || "") + " · 파란 라디오 확인 뒤 Shopling 원본 송신 함수를 실행하지 못했습니다.",
          {
            code: receipt?.code || "SHOPLING_HF83_COMMIT_RECEIPT_MISSING",
            popupTabId: chosen.tabId,
            popupFrameId: chosen.frameId,
            receipt,
            retrySafe: true,
            externalWriteConfirmed: false,
          },
        );
        return;
      }

      committedHf83.add(key);
      readinessHf83.delete(key);
      latest.lastMileReceiptHf83 = {
        ...receipt,
        popupTabId: chosen.tabId,
        popupFrameId: chosen.frameId,
        goodsKeyQuery: batchQueryHf83(latest),
        assignmentOwnerKey: binding.assignmentOwnerKey,
        probeAttempts: current.attempts,
        recordedAt: Date.now(),
      };
      latest.stage = "WAIT_A21_RESULT";
      latest.stageStartedAt = Date.now();
      await saveActive(latest);
      await progress(
        latest,
        String(latest.job?.barcode || "") + " · 정확한 Shopling 프레임에서 "
          + receipt.topLabel + " → " + receipt.targetLabel
          + " 확인 · 원본 상품수정 송신 함수 실행 완료",
        {
          code: "SHOPLING_HF83_EXACT_FRAME_COMMITTED",
          lastMileReceipt: latest.lastMileReceiptHf83,
          extensionVersion: VERSION_HF83,
        },
      );
    } finally {
      inFlightHf83.delete(key);
    }
  }

  function scheduleHf83(tabId, tabUrl) { void tabId; void tabUrl; }

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const href = String(tab?.url || tab?.pendingUrl || "");
    if (changeInfo.status === "complete" || changeInfo.url) scheduleHf83(tabId, href);
  });
  chrome.tabs.onCreated.addListener((tab) => {
    const tabId = Number(tab?.id);
    if (!Number.isInteger(tabId)) return;
    setTimeout(async () => {
      const current = await chrome.tabs.get(tabId).catch(() => null);
      scheduleHf83(tabId, String(current?.url || current?.pendingUrl || ""));
    }, 150);
  });
  setTimeout(async () => {
    const tabs = await chrome.tabs.query({ url: POPUP_URLS_HF83 }).catch(() => []);
    for (const tab of tabs) {
      scheduleHf83(Number(tab?.id), String(tab?.url || tab?.pendingUrl || ""));
    }
  }, 400);

  if (globalThis.__COMMERCE_OS_EXPOSE_STOCK_HF83_TEST_HOOKS__ === true) {
    globalThis.__commerceOsStockHf83TestHooks = {
      exactPopupUrlHf83,
      batchQueryHf83,
      receiptKeyHf83,
      bindingMatchesHf83,
      scanOwnedFramesHf83,
      probeThenCommitHf83,
    };
  }
  console.log(
    "[CommerceOS Stock HF83]",
    new Date().toISOString(),
    "read-only all-frame probe then exact-frame original Shopling submit",
    VERSION_HF83,
  );
})();


// COMMERCE_OS_STOCK_HF84_MODE_THEN_TARGET
(() => {
  const VERSION_HF84 = chrome.runtime.getManifest().version;
  const POPUP_PATH_HF84 = "/prodlinkage/goods_mallMdfy_trsmt.phtml";
  const POPUP_URLS_HF84 = [
    "https://a.shopling.co.kr/prodlinkage/goods_mallMdfy_trsmt.phtml*",
    "https://kt.shopling.co.kr/prodlinkage/goods_mallMdfy_trsmt.phtml*",
  ];
  const READY_TIMEOUT_MS_HF84 = 15000;
  const inFlightHf84 = new Set();
  const readinessHf84 = new Map();
  const committedHf84 = new Set();
  const probeLastMileHf84 = function r(e){let t=e=>String(e??"").normalize("NFKC").replace(/\s+/g," ").trim(),n=e=>t(e).replace(/\s+/g,""),r=e=>{if(!(e instanceof HTMLElement))return!1;let t=getComputedStyle(e);return"none"!==t.display&&"hidden"!==t.visibility&&e.getClientRects().length>0},i=()=>[...document.querySelectorAll('input[type="radio"]')].filter(r),o=e=>n(e.closest("td,th,label")?.textContent),a=t(e?.productKind).toUpperCase(),l=t(e?.desiredStatus).toUpperCase(),s="OPTION"===a?"옵션송신":"상품판매상태송신",c="OPTION"===a?"옵션송신":["SOLD_OUT","OUT_OF_STOCK"].includes(l)?"품절":"ON_SALE"===l?"판매중":"";if(!["OPTION","SINGLE"].includes(a)||!c)return{eligible:!1,code:"HF84_PROBE_INPUT_INVALID"};let d=((e,t)=>{let r=n(e);if("OPTION"===t){let e=i().filter(e=>"modify_tp"===e.name&&"goods_stock"===String(e.value));if(e.length)return e}let a=i().filter(e=>(e=>{let t=[e.closest("label")?.textContent,e.previousSibling?.textContent||e.previousSibling?.nodeValue,e.nextSibling?.textContent||e.nextSibling?.nodeValue,e.previousElementSibling?.textContent,e.nextElementSibling?.textContent];if(e.id)for(let n of document.querySelectorAll("label"))n.htmlFor===e.id&&t.push(n.textContent);return[...new Set(t.map(n).filter(Boolean))]})(e).includes(r)||o(e)===r);if(a.length)return a;let l=i().map(e=>{let t=e.getBoundingClientRect();return{radio:e,top:Math.round(Number(t.top)||0),left:Math.round(Number(t.left)||0),cell:o(e)}}).sort((e,t)=>e.top-t.top||e.left-t.left);if(l.length<3)return[];let s=l.filter(e=>8>=Math.abs(e.top-l[0].top)).sort((e,t)=>e.left-t.left),c=["일반내용수정","상품판매상태송신","옵션송신"];if(3!==s.length||!s.every((e,t)=>e.cell===n(c[t])))return[];let d=c.indexOf(e);return d>=0?[s[d].radio]:[]})(s,a),u=((e,t)=>{if("OPTION"===t){let e=i().filter(e=>"trsmt_env_mody_opt"===e.name&&"1"===String(e.value));if(e.length)return e}let o=n(e);return[...document.querySelectorAll("tr")].filter(r).filter(e=>[...e.querySelectorAll(":scope > th, :scope > td")].some(e=>n(e.textContent)===o)).flatMap(e=>{let t=[...e.querySelectorAll('input[type="radio"]')].filter(r),i=t.filter(e=>"선택"===n(e.closest("td,th")?.textContent));return i.length?i:t})})(c,a),f=[...document.querySelectorAll("input,button,a")].filter(r).filter(e=>"상품수정 송신"===t(e instanceof HTMLInputElement?e.value:e.textContent)),_=[...document.querySelectorAll('input[type="hidden"]')].filter(e=>"prod_join_chk[]"===e.name).map(e=>String(e.value??"")),p=_.length>0&&_.every(e=>/^\d+$/.test(e)),m="function"==typeof window.goods_mallMdfy_submit_sp,h=1===d.length&&!d[0].disabled&&1===u.length&&d[0]!==u[0]&&1===f.length&&p&&m;return{eligible:h,code:h?u[0].disabled?"HF84_PROBE_READY_TARGET_DISABLED_UNTIL_MODE":"HF84_PROBE_READY":"HF84_PROBE_NOT_READY",productKind:a,desiredStatus:l,topLabel:s,targetLabel:c,topCount:d.length,targetCount:u.length,topDisabled:1===d.length?!!d[0].disabled:null,targetDisabled:1===u.length?!!u[0].disabled:null,submitCount:f.length,payloadCount:_.length,payloadValid:p,submitFunctionReady:m,radioDiagnostics:i().slice(0,24).map((e,n)=>{let r=e.getBoundingClientRect();return{index:n,name:String(e.name||"").slice(0,80),value:String(e.value||"").slice(0,80),checked:!!e.checked,disabled:!!e.disabled,cellText:t(e.closest("td,th")?.textContent).slice(0,120),rowText:t(e.closest("tr")?.textContent).slice(0,180),top:Math.round(Number(r.top)||0),left:Math.round(Number(r.left)||0)}}),pathname:String(window.location?.pathname||"")}};
  const commitLastMileHf84 = async function i(e){let t=e=>new Promise(t=>setTimeout(t,e)),n=e=>String(e??"").normalize("NFKC").replace(/\s+/g," ").trim(),r=e=>n(e).replace(/\s+/g,""),i=e=>{if(!(e instanceof HTMLElement))return!1;let t=getComputedStyle(e);return"none"!==t.display&&"hidden"!==t.visibility&&e.getClientRects().length>0},o=()=>[...document.querySelectorAll('input[type="radio"]')].filter(i),a=e=>r(e.closest("td,th,label")?.textContent),l=(e,t)=>{let n=r(e);if("OPTION"===t){let e=o().filter(e=>"modify_tp"===e.name&&"goods_stock"===String(e.value));if(e.length)return e}let i=o().filter(e=>(e=>{let t=[e.closest("label")?.textContent,e.previousSibling?.textContent||e.previousSibling?.nodeValue,e.nextSibling?.textContent||e.nextSibling?.nodeValue,e.previousElementSibling?.textContent,e.nextElementSibling?.textContent];if(e.id)for(let n of document.querySelectorAll("label"))n.htmlFor===e.id&&t.push(n.textContent);return[...new Set(t.map(r).filter(Boolean))]})(e).includes(n)||a(e)===n);if(i.length)return i;let l=o().map(e=>{let t=e.getBoundingClientRect();return{radio:e,top:Math.round(Number(t.top)||0),left:Math.round(Number(t.left)||0),cell:a(e)}}).sort((e,t)=>e.top-t.top||e.left-t.left);if(l.length<3)return[];let s=l.filter(e=>8>=Math.abs(e.top-l[0].top)).sort((e,t)=>e.left-t.left),c=["일반내용수정","상품판매상태송신","옵션송신"];if(3!==s.length||!s.every((e,t)=>e.cell===r(c[t])))return[];let d=c.indexOf(e);return d>=0?[s[d].radio]:[]},s=(e,t)=>{if("OPTION"===t){let e=o().filter(e=>"trsmt_env_mody_opt"===e.name&&"1"===String(e.value));if(e.length)return e}let n=r(e);return[...document.querySelectorAll("tr")].filter(i).filter(e=>[...e.querySelectorAll(":scope > th, :scope > td")].some(e=>r(e.textContent)===n)).flatMap(e=>{let t=[...e.querySelectorAll('input[type="radio"]')].filter(i),n=t.filter(e=>"선택"===r(e.closest("td,th")?.textContent));return n.length?n:t})},c=()=>o().slice(0,24).map((e,t)=>({index:t,name:String(e.name||"").slice(0,80),value:String(e.value||"").slice(0,80),checked:!!e.checked,disabled:!!e.disabled,cellText:n(e.closest("td,th")?.textContent).slice(0,120),rowText:n(e.closest("tr")?.textContent).slice(0,180)})),d=e=>1===e.length?e[0]:null,u=async e=>{if(!e||e.disabled||!i(e))return!1;if(e.checked)return!0;try{e.scrollIntoView({block:"center",inline:"center"})}catch{}let n=e.id?[...document.querySelectorAll("label")].find(t=>t.htmlFor===e.id)||null:e.closest("label");try{n?.click()}catch{}await t(40);try{e.click()}catch{}if(await t(40),!e.checked){try{HTMLInputElement.prototype.click.call(e)}catch{}await t(40)}if(!e.checked){let n=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"checked");n?.set?.call(e,!0),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),await t(40)}return!!e.checked},f=n(e?.productKind).toUpperCase(),_=n(e?.desiredStatus).toUpperCase(),p="OPTION"===f?"옵션송신":"상품판매상태송신",m="OPTION"===f?"옵션송신":["SOLD_OUT","OUT_OF_STOCK"].includes(_)?"품절":"ON_SALE"===_?"판매중":"";if(!["OPTION","SINGLE"].includes(f)||!m)return{ok:!1,code:"HF84_COMMIT_INPUT_INVALID"};let h=n(e?.receiptKey);if(h&&document.documentElement.dataset.commerceOsHf84Commit===h)return{ok:!0,duplicate:!0,receiptKey:h,productKind:f,desiredStatus:_,topLabel:p,targetLabel:m,topChecked:!0,targetChecked:!0,shoplingSubmitInvoked:!0,submitDispatchMethod:"ORIGINAL_SHOPLING_FUNCTION"};let b=d(l(p,f));if(!b)return{ok:!1,code:"HF84_TOP_RADIO_NOT_UNIQUE",topLabel:p,radioDiagnostics:c()};if(!await u(b))return{ok:!1,code:"HF84_TOP_RADIO_CHECK_FAILED",topLabel:p,radioDiagnostics:c()};let g=null;for(let e=0;e<30&&(!(g=d(s(m,f)))||g.disabled);e+=1)await t(100);if(!g||g.disabled)return{ok:!1,code:"HF84_TARGET_REMAINED_DISABLED_AFTER_MODE",topLabel:p,targetLabel:m,topChecked:d(l(p,f))?.checked===!0,radioDiagnostics:c()};if(!await u(g))return{ok:!1,code:"HF84_TARGET_RADIO_CHECK_FAILED",targetLabel:m,radioDiagnostics:c()};await t(160);let I=d(l(p,f)),S=d(s(m,f));if(!I?.checked||!S?.checked||S.disabled)return{ok:!1,code:"HF84_EXACT_RADIO_READBACK_FAILED",topChecked:I?.checked===!0,targetChecked:S?.checked===!0,targetDisabled:S?.disabled===!0,radioDiagnostics:c()};let T=[...document.querySelectorAll('input[type="hidden"]')].filter(e=>"prod_join_chk[]"===e.name).map(e=>String(e.value??""));if(!T.length||T.some(e=>!/^\d+$/.test(e)))return{ok:!1,code:"HF84_EXACT_PAYLOAD_INVALID",payloadCount:T.length};let E=[...document.querySelectorAll("input,button,a")].filter(i).filter(e=>"상품수정 송신"===n(e instanceof HTMLInputElement?e.value:e.textContent));if(1!==E.length)return{ok:!1,code:"HF84_EXACT_SUBMIT_CONTROL_INVALID",submitCount:E.length};let O=window,y=O.goods_mallMdfy_submit_sp;if("function"!=typeof y)return{ok:!1,code:"HF84_SHOPLING_SUBMIT_FUNCTION_MISSING"};let H=O.confirm,C=!1,N="";O.confirm=e=>{let t=n(e);return/수정전송\s*할\s*상품을\s*선택하셨습니까/.test(t)?(C=!0,!0):(N=t.slice(0,240),!1)};try{y.call(O)}catch(e){return{ok:!1,code:"HF84_SHOPLING_SUBMIT_FUNCTION_THROWN",error:e instanceof Error?e.message:String(e)}}finally{O.confirm=H}return N?{ok:!1,code:"HF84_UNEXPECTED_CONFIRM_BLOCKED",unexpectedConfirm:N}:(h&&(document.documentElement.dataset.commerceOsHf84Commit=h),{ok:!0,receiptKey:h,productKind:f,desiredStatus:_,topLabel:p,targetLabel:m,topChecked:!0,targetChecked:!0,targetEnabledAfterMode:!0,shoplingSubmitInvoked:!0,submitConfirmSeen:C,submitControlVerified:!0,submitDispatchMethod:"ORIGINAL_SHOPLING_FUNCTION",payloadCount:T.length,invokedAt:Date.now()})};

  const normHf84 = (value) => String(value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim();
  function exactPopupUrlHf84(value) {
    try {
      const url = new URL(String(value || ""));
      return ["a.shopling.co.kr", "kt.shopling.co.kr"].includes(url.hostname)
        && url.pathname === POPUP_PATH_HF84;
    } catch { return false; }
  }
  function batchQueryHf84(active) {
    const option = String(active?.job?.productKind || "").toUpperCase() === "OPTION";
    const values = option ? active?.optionCurrentBatchKeys : active?.singleCurrentBatchKeys;
    return (Array.isArray(values) ? values : active?.job?.goodsKeys || [])
      .map(normHf84).filter(Boolean).join(",");
  }
  function receiptKeyHf84(active) {
    return [
      String(active?.job?.jobId || ""),
      String(active?.job?.executionId || active?.job?.jobId || ""),
      String(active?.job?.productKind || "").toUpperCase(),
      batchQueryHf84(active),
    ].join(":");
  }
  function bindingMatchesHf84(active, tabId) {
    const binding = active?.a21PopupOwnershipHf81;
    const productKind = String(active?.job?.productKind || "").toUpperCase();
    const goodsKeyQuery = batchQueryHf84(active);
    const runId = String(active?.job?.executionId || active?.job?.jobId || "");
    const ownerKey = [String(active?.job?.jobId || ""), runId, productKind, goodsKeyQuery].join(":");
    if (!binding || !["OPTION", "SINGLE"].includes(productKind) || !goodsKeyQuery) return false;
    if (binding.productKind !== productKind || binding.goodsKeyQuery !== goodsKeyQuery) return false;
    if (binding.assignmentOwnerKey !== ownerKey) return false;
    const baseline = new Set((binding.baselineTabIds || []).map(Number).filter(Number.isInteger));
    if (baseline.has(tabId)) return false;
    const claimed = binding.claimedTabId == null ? null : Number(binding.claimedTabId);
    return !Number.isInteger(claimed) || claimed === tabId;
  }
  async function scanOwnedFramesHf84(active) {
    const tabs = await chrome.tabs.query({ url: POPUP_URLS_HF84 }).catch(() => []);
    const candidates = tabs.filter((tab) => Number.isInteger(tab?.id)
      && exactPopupUrlHf84(tab.url || tab.pendingUrl)
      && bindingMatchesHf84(active, Number(tab.id)));
    const rows = [];
    for (const tab of candidates) {
      const tabId = Number(tab.id);
      const injected = await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        world: "MAIN",
        func: probeLastMileHf84,
        args: [{ productKind: active.job.productKind, desiredStatus: active.job.desiredStatus }],
      }).catch(() => []);
      for (const item of injected) rows.push({
        tabId,
        frameId: Number(item?.frameId),
        result: item?.result || null,
      });
    }
    return { candidates, rows, eligible: rows.filter((row) => row.result?.eligible === true) };
  }
  async function probeThenCommitHf84() {
    const active = await loadActive();
    if (!active || active.status !== "RUNNING"
      || !["A21_LIST", "A21_POPUP"].includes(String(active.stage || ""))) return;
    const key = receiptKeyHf84(active);
    if (!key || committedHf84.has(key) || inFlightHf84.has(key)) return;
    inFlightHf84.add(key);
    try {
      const current = readinessHf84.get(key) || { startedAt: Date.now(), attempts: 0 };
      current.attempts += 1;
      readinessHf84.set(key, current);
      const scan = await scanOwnedFramesHf84(active);
      if (scan.eligible.length !== 1) {
        if (Date.now() - current.startedAt < READY_TIMEOUT_MS_HF84) {
          setTimeout(() => void probeThenCommitHf84(), 300);
          return;
        }
        readinessHf84.delete(key);
        await finish(active, "FAILED",
          String(active.job?.barcode || "") + " · A21 선택 구조를 가진 단 하나의 실행 프레임을 확인하지 못했습니다.", {
            code: scan.eligible.length > 1
              ? "SHOPLING_HF84_AMBIGUOUS_STRUCTURAL_FRAMES"
              : "SHOPLING_HF84_STRUCTURAL_FRAME_TIMEOUT",
            candidateTabIds: scan.candidates.map((tab) => Number(tab.id)),
            frameDiagnostics: scan.rows.map((row) => ({
              tabId: row.tabId, frameId: row.frameId, result: row.result,
            })),
            retrySafe: true,
            externalWriteConfirmed: false,
          });
        return;
      }
      const chosen = scan.eligible[0];
      const latest = await loadActive();
      if (!latest || latest.status !== "RUNNING" || receiptKeyHf84(latest) !== key
        || !bindingMatchesHf84(latest, chosen.tabId)) return;
      const binding = latest.a21PopupOwnershipHf81;
      binding.claimedTabId = chosen.tabId;
      binding.claimedFrameId = chosen.frameId;
      binding.claimedAt = Date.now();
      latest.stage = "A21_POPUP";
      latest.stageStartedAt = Date.now();
      latest.workTabs = { ...(latest.workTabs || {}), A21_POPUP: {
        tabId: chosen.tabId, frameId: chosen.frameId,
      } };
      latest.shoplingTabId = chosen.tabId;
      latest.shoplingFrameId = chosen.frameId;
      if (String(latest.job?.productKind || "").toUpperCase() === "SINGLE") {
        latest.singlePopupTabId = chosen.tabId;
      }
      await saveActive(latest);
      const injected = await chrome.scripting.executeScript({
        target: { tabId: chosen.tabId, frameIds: [chosen.frameId] },
        world: "MAIN",
        func: commitLastMileHf84,
        args: [{
          productKind: latest.job.productKind,
          desiredStatus: latest.job.desiredStatus,
          receiptKey: key,
        }],
      }).catch(() => []);
      const receipt = injected.map((item) => item?.result)
        .find((item) => item?.receiptKey === key) || injected[0]?.result || null;
      if (!receipt?.ok || receipt?.shoplingSubmitInvoked !== true
        || receipt?.topChecked !== true || receipt?.targetChecked !== true
        || receipt?.targetEnabledAfterMode !== true
        || receipt?.submitDispatchMethod !== "ORIGINAL_SHOPLING_FUNCTION") {
        await finish(latest, "FAILED",
          String(latest.job?.barcode || "") + " · 상단 선택 뒤 하단 라디오 활성화·선택·송신을 완료하지 못했습니다.", {
            code: receipt?.code || "SHOPLING_HF84_COMMIT_RECEIPT_MISSING",
            popupTabId: chosen.tabId,
            popupFrameId: chosen.frameId,
            receipt,
            retrySafe: true,
            externalWriteConfirmed: false,
          });
        return;
      }
      committedHf84.add(key);
      readinessHf84.delete(key);
      latest.lastMileReceiptHf84 = {
        ...receipt,
        popupTabId: chosen.tabId,
        popupFrameId: chosen.frameId,
        goodsKeyQuery: batchQueryHf84(latest),
        assignmentOwnerKey: binding.assignmentOwnerKey,
        probeAttempts: current.attempts,
        recordedAt: Date.now(),
      };
      latest.stage = "WAIT_A21_RESULT";
      latest.stageStartedAt = Date.now();
      await saveActive(latest);
      await progress(latest,
        String(latest.job?.barcode || "") + " · " + receipt.topLabel
          + " 선택 → " + receipt.targetLabel
          + " 활성화·선택 확인 → 원본 상품수정 송신 완료", {
            code: "SHOPLING_HF84_MODE_THEN_TARGET_COMMITTED",
            lastMileReceipt: latest.lastMileReceiptHf84,
            extensionVersion: VERSION_HF84,
          });
    } finally { inFlightHf84.delete(key); }
  }
  function scheduleHf84(tabId, tabUrl) {
    if (!Number.isInteger(tabId) || !exactPopupUrlHf84(tabUrl)) return;
    for (const delay of [80, 250, 700, 1600]) {
      setTimeout(() => void probeThenCommitHf84(), delay);
    }
  }
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const href = String(tab?.url || tab?.pendingUrl || "");
    if (changeInfo.status === "complete" || changeInfo.url) scheduleHf84(tabId, href);
  });
  chrome.tabs.onCreated.addListener((tab) => {
    const tabId = Number(tab?.id);
    if (!Number.isInteger(tabId)) return;
    setTimeout(async () => {
      const current = await chrome.tabs.get(tabId).catch(() => null);
      scheduleHf84(tabId, String(current?.url || current?.pendingUrl || ""));
    }, 150);
  });
  setTimeout(async () => {
    const tabs = await chrome.tabs.query({ url: POPUP_URLS_HF84 }).catch(() => []);
    for (const tab of tabs) scheduleHf84(Number(tab?.id), String(tab?.url || tab?.pendingUrl || ""));
  }, 400);
  if (globalThis.__COMMERCE_OS_EXPOSE_STOCK_HF84_TEST_HOOKS__ === true) {
    globalThis.__commerceOsStockHf84TestHooks = {
      exactPopupUrlHf84, batchQueryHf84, receiptKeyHf84,
      bindingMatchesHf84, scanOwnedFramesHf84, probeThenCommitHf84,
    };
  }
  console.log("[CommerceOS Stock HF84]", new Date().toISOString(),
    "structural probe then mode-select, dependent-target-enable, target-select, original submit",
    VERSION_HF84);
})();
