// Read-only search policy. No product/option mutation occurs in this module.
// HF62: a submitted exact search is resumed by its execution-scoped ticket even
// when Shopling clears the visible search controls during the result reload.
(() => {
  const START = "20230101";
  const documentToken = `${Date.now()}-${Math.random()}`;
  const completed = new Map();
  const norm = (v) => String(v ?? "").replace(/\s+/g, " ").trim();
  const digits = (v) => String(v ?? "").replace(/\D/g, "");
  const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  function todayKst(now = new Date()) {
    const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Seoul", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
    return ["year", "month", "day"].map((type) => parts.find((p) => p.type === type).value).join("");
  }
  function dateValue(input, value) {
    const old = String(input.value || "");
    const sep = input.type === "date" || old.includes("-") ? "-" : old.includes("/") ? "/" : old.includes(".") ? "." : "";
    return [value.slice(0, 4), value.slice(4, 6), value.slice(6)].join(sep);
  }
  function dateFieldDiagnostics(form) {
    return [...form.querySelectorAll("input")]
      .filter((el) => visible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const context = norm(el.closest("tr")?.textContent || el.parentElement?.textContent);
        return { name: String(el.name || ""), id: String(el.id || ""), type: String(el.type || ""), valueDigits: digits(el.value), context: context.slice(0, 120), top: Math.round(rect.top), left: Math.round(rect.left) };
      })
      .filter((item) => /일자|날짜|기간|등록일|date/i.test(`${item.context} ${item.name} ${item.id}`))
      .slice(0, 12);
  }
  function datePair(form) {
    const namedStarts = [...form.querySelectorAll('input[name="s_dt"], input#s_dt')];
    const namedEnds = [...form.querySelectorAll('input[name="e_dt"], input#e_dt')];
    if (namedStarts.length === 1 && namedEnds.length === 1 && namedStarts[0] !== namedEnds[0]) {
      return [namedStarts[0], namedEnds[0]];
    }
    const inputs = [...form.querySelectorAll("input")].filter((el) => {
      const type = String(el.type || "text").toLowerCase();
      if (!["text", "date", "search"].includes(type) || !visible(el)) return false;
      const context = norm(el.closest("tr")?.textContent || el.parentElement?.textContent);
      const metadata = `${context} ${el.name || ""} ${el.id || ""} ${el.placeholder || ""}`;
      const valueDigits = digits(el.value);
      const hasDateSemantics = /일자|날짜|기간|등록일|date/i.test(metadata);
      const hasDateValue = /^20\d{6}$|^201\d{5}$/.test(valueDigits);
      return hasDateSemantics && (hasDateValue || valueDigits.length === 0);
    });
    const pairs = [];
    for (let i = 0; i < inputs.length; i++) for (let j = i + 1; j < inputs.length; j++) {
      const a = inputs[i], b = inputs[j], ar = a.getBoundingClientRect(), br = b.getBoundingClientRect();
      if (Math.abs(ar.top - br.top) <= 18 && (a.closest("tr") === b.closest("tr") || Math.abs(ar.left - br.left) < 240)) pairs.push(ar.left <= br.left ? [a, b] : [b, a]);
    }
    return pairs.length === 1 ? pairs[0] : null;
  }
  function applyPeriod(form, setInput, now = new Date()) {
    const pair = datePair(form);
    if (!pair) return { ok: false, code: "SEARCH_DATE_FIELDS_AMBIGUOUS", message: "검색 시작일·종료일을 정확히 특정하지 못해 검색을 차단했습니다.", evidence: { stage: "PRE_SEARCH_DATE_BINDING", mutationAttempted: false, dateCandidates: dateFieldDiagnostics(form) } };
    const end = todayKst(now);
    if (pair.some((el) => el.disabled)) return { ok: false, code: "SEARCH_DATE_DISABLED", message: "검색 날짜 입력칸이 비활성화되어 검색을 차단했습니다." };
    for (const [index, value] of [START, end].entries()) if (digits(pair[index].value) !== value) setInput(pair[index], dateValue(pair[index], value));
    const evidence = { start: digits(pair[0].value), end: digits(pair[1].value), expectedStart: START, expectedEnd: end };
    if (evidence.start !== START || evidence.end !== end) return { ok: false, code: "SEARCH_DATE_VERIFY_FAILED", message: "2023-01-01~오늘 검색기간 설정값 검증에 실패했습니다.", evidence };
    return { ok: true, evidence };
  }
  function resultEvidence(api) {
    const total = typeof api.resultCount === "function" ? api.resultCount() : null;
    return { totalResultCount: Number.isFinite(total) ? total : null };
  }
  async function awaitRows(token, api, timeoutMs) {
    return api.waitFor(() => { const found = api.rows(token); return found.length ? found : null; }, timeoutMs, 200);
  }
  function bindingEvidence(fieldLabel, token, field, input) {
    return { expectedFieldLabel: fieldLabel, selectedFieldLabel: norm(field?.options?.[field.selectedIndex]?.textContent), expectedToken: norm(token).toUpperCase(), inputToken: norm(input?.value).toUpperCase() };
  }
  function bindingMatches(evidence) { return evidence.selectedFieldLabel === evidence.expectedFieldLabel && evidence.inputToken === evidence.expectedToken; }
  async function search(fieldLabel, token, api) {
    let field = api.getField(fieldLabel);
    if (!field) return { ok: false, code: "SEARCH_FIELD_NOT_FOUND", message: `${fieldLabel} 검색항목을 찾지 못했습니다.` };
    let input = api.findInput(field);
    const scope = `${api.scope}:${location.pathname}:${fieldLabel}:${token}`;
    const key = `commerce-stock-search-v042:${scope}`;
    let ticket = null;
    try { ticket = JSON.parse(sessionStorage.getItem(key) || "null"); } catch {}
    const inDateRange = (e) => e?.start === START && e?.end === todayKst();
    const form = field.form || field.closest("form") || document;
    const pair = datePair(form);
    const currentPeriod = pair ? { start: digits(pair[0].value), end: digits(pair[1].value) } : null;
    const initialBinding = bindingEvidence(fieldLabel, token, field, input);
    const queryMatches = bindingMatches(initialBinding) && inDateRange(currentPeriod);
    const submittedTicket = Boolean(
      ticket &&
      ticket.submitted === true &&
      Date.now() - Number(ticket.at || 0) < 90_000 &&
      ticket.fieldLabel === fieldLabel &&
      String(ticket.token || "").toUpperCase() === norm(token).toUpperCase()
    );
    if (submittedTicket || (completed.has(scope) && queryMatches)) {
      const rows = await awaitRows(token, api, 20_000);
      const submittedPeriod = ticket?.period || currentPeriod;
      if (!rows?.length) {
        const evidence = {
          ...(submittedPeriod || {}),
          ...resultEvidence(api),
          binding: initialBinding,
          oneClickGuard: submittedTicket,
          resumedFromSubmittedTicket: submittedTicket,
          controlsStillEchoQuery: queryMatches,
          submittedDocumentToken: ticket?.documentToken || null,
          resumedDocumentToken: documentToken,
        };
        const code = Number(evidence.totalResultCount || 0) > 0 ? "EXACT_RESULT_ROW_NOT_BOUND" : "EXACT_RESULT_NOT_FOUND";
        return { ok: false, code, message: Number(evidence.totalResultCount || 0) > 0 ? `${token} 조회결과 ${evidence.totalResultCount}건은 확인했지만 정확 행을 worker가 연결하지 못했습니다.` : `${token} 정확 일치 검색결과가 없습니다. 동일 작업에서 검색 버튼을 다시 누르지 않았습니다.`, evidence };
      }
      completed.set(scope, true);
      return { ok: true, rows, fieldLabel, period: submittedPeriod, resumedFromSubmittedTicket: submittedTicket };
    }
    if (!api.selectField(field, fieldLabel)) return { ok: false, code: "SEARCH_FIELD_NOT_FOUND", message: `${fieldLabel} 검색항목을 선택하지 못했습니다.` };
    input = await api.waitFor(() => { field = api.getField(fieldLabel) || field; return api.findInput(field); }, 6_000, 120);
    if (!input) return { ok: false, code: "SEARCH_INPUT_NOT_BOUND", message: `${fieldLabel}과 같은 검색행의 입력칸을 찾지 못해 검색을 차단했습니다.` };
    if (!api.setInput(input, token)) return { ok: false, code: "SEARCH_INPUT_SET_FAILED", message: `${fieldLabel} 검색어 ${token}을 입력하지 못했습니다.` };
    field = api.getField(fieldLabel) || field; input = api.findInput(field) || input;
    const verifiedBinding = bindingEvidence(fieldLabel, token, field, input);
    if (!bindingMatches(verifiedBinding)) return { ok: false, code: "SEARCH_BINDING_MISMATCH", message: `${fieldLabel} 검색항목과 검색어 입력칸의 결합 검증에 실패해 검색 버튼을 누르지 않았습니다.`, evidence: verifiedBinding };
    const period = applyPeriod(input.form || form, api.setInput);
    if (!period.ok) return period;
    await api.sleep(120);
    const livePair = datePair(input.form || form);
    const finalBinding = bindingEvidence(fieldLabel, token, field, input);
    if (!bindingMatches(finalBinding)) return { ok: false, code: "SEARCH_BINDING_MISMATCH", message: "검색 직전 검색항목 또는 검색어가 변경되어 실행을 차단했습니다.", evidence: finalBinding };
    if (!livePair || digits(livePair[0].value) !== START || digits(livePair[1].value) !== todayKst()) return { ok: false, code: "SEARCH_DATE_VERIFY_FAILED", message: "검색 직전 날짜가 변경되어 실행을 차단했습니다." };
    try { sessionStorage.setItem(key, JSON.stringify({ at: Date.now(), documentToken, fieldLabel, token: norm(token).toUpperCase(), period: period.evidence, submitted: true })); }
    catch { return { ok: false, code: "SEARCH_CONTINUATION_STORAGE_FAILED", message: "검색 후 화면 복구정보를 저장하지 못해 실행을 차단했습니다." }; }
    if (!api.clickSearch(input)) return { ok: false, code: "SEARCH_BUTTON_NOT_FOUND", message: "검색 버튼을 찾지 못했습니다." };
    const rows = await awaitRows(token, api, 30_000);
    if (!rows?.length) {
      const evidence = { ...period.evidence, ...resultEvidence(api), binding: finalBinding, oneClickGuard: true };
      const code = Number(evidence.totalResultCount || 0) > 0 ? "EXACT_RESULT_ROW_NOT_BOUND" : "EXACT_RESULT_NOT_FOUND";
      return { ok: false, code, message: Number(evidence.totalResultCount || 0) > 0 ? `${token} 조회결과 ${evidence.totalResultCount}건은 확인했지만 정확 행을 worker가 연결하지 못했습니다.` : `${token} 정확 일치 검색결과가 없습니다. 동일 작업에서 검색 버튼을 다시 누르지 않습니다.`, evidence };
    }
    completed.set(scope, true);
    return { ok: true, rows, fieldLabel, period: period.evidence };
  }
  globalThis.CommerceStockSearchV023 = { search, applyPeriod, datePair, todayKst };
})();
(() => {
  const VERSION = "0.5.5";  if (globalThis.__commerceStockWorkerV055HF3) return;  globalThis.__commerceStockWorkerV055HF3 = true;  let executionContext = {};
  const IS_TOP = window.top === window;
  const MAIN_REQUEST = "commerce-os-stock-main-click";
  const MAIN_RESULT = "commerce-os-stock-main-click-result";
  const MAIN_TOKEN_ATTRIBUTE = "data-commerce-os-stock-click-token";
  const handled = new Set();
  let lastEvidenceSignature = "";

  const norm = (value) => String(value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim();
  const compact = (value) => norm(value).replace(/\s+/g, "");
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const bodyText = () => norm(document.body?.innerText || document.body?.textContent || document.documentElement?.innerText || "");

  function visible(element) {
    if (!(element instanceof HTMLElement)) return true;
    const rect = element.getBoundingClientRect();
    return element.offsetParent !== null || rect.width > 0 || rect.height > 0;
  }

  function controlText(element) {
    if (!element) return "";
    const values = [
      element.textContent,
      element.value,
      element.title,
      element.alt,
      element.name,
      element.id,
      element.getAttribute?.("aria-label"),
    ];
    if (element.id) {
      const label = document.querySelector(`label[for="${CSS.escape(element.id)}"]`);
      if (label) values.push(label.textContent);
    }
    const wrappingLabel = element.closest?.("label");
    if (wrappingLabel) values.push(wrappingLabel.textContent);
    return norm(values.filter(Boolean).join(" "));
  }

  function localText(element) {
    const values = [controlText(element)];
    let cursor = element?.parentElement;
    for (let depth = 0; cursor && depth < 3; depth += 1) {
      values.push(cursor.textContent || "");
      cursor = cursor.parentElement;
    }
    return norm(values.join(" "));
  }

  function role() {
    const text = bodyText();
    const href = String(location.href || "");
    if (selectWithOption("옵션자체관리코드").length) return "A6";
    if (/검색항목/.test(text) && selectWithOption("샵플링상품코드").length) {
      if (/쇼핑몰상품수정|상품\s*수정전송/i.test(text)) return "A21_LIST";
      if (/상품조회수정/i.test(text)) return "A4";
    }
    if (
      /상품수정\s*송신/i.test(text) &&
      (/상품판매상태송신/i.test(text) || /상품?옵션(?:송신|전송)/i.test(text) || /옵션송신/i.test(text))
    ) {
      return "A21_POPUP";
    }
    if (
      /상품(?:옵션)?\s*(?:수정\s*)?전송이\s*완료되었습니다/i.test(text) ||
      /처리중입니다/i.test(text) ||
      /성공건수\s*[:：]/i.test(text)
    ) {
      return "RESULT";
    }
    if (selectWithOption("옵션자체관리코드").length) return "A6";
    if ((/상품조회수정/i.test(text) || String(location.pathname || "").toLowerCase() === "/prod/prodlst.phtml") && !/goods_mallMdfy_trsmt\.phtml/i.test(href)) return "A4";
    if (/쇼핑몰상품수정/i.test(text) && /상품\s*수정전송/i.test(text) && !/goods_mallMdfy_trsmt\.phtml/i.test(href)) {
      return "A21_LIST";
    }
    return "OTHER";
  }

  function menuPatternFor(stage) {
    if (stage === "A4") return /(?:\[?A?4\]?[:.\-]?\s*)?상품조회수정/i;
    if (stage === "A6") return /(?:\[?A?6\]?[:.\-]?\s*)?옵션대량수정/i;
    if (stage === "A21_LIST") return /(?:\[?A?21\]?[:.\-]?\s*)?쇼핑몰상품수정/i;
    return /$a/;
  }

  function menuTarget(labelPattern) {
    if (!labelPattern) return null;
    const candidates = [...document.querySelectorAll("a,[onclick],li,td,span,div")].filter((element) => {
      if (!visible(element)) return false;
      const value = norm(element.textContent);
      if (!value || value.length > 80) return false;
      return labelPattern.test(value);
    });
    candidates.sort((left, right) => {
      const leftAnchor = left.matches("a,[onclick]") ? 0 : 1;
      const rightAnchor = right.matches("a,[onclick]") ? 0 : 1;
      return leftAnchor - rightAnchor || norm(left.textContent).length - norm(right.textContent).length;
    });
    const target = candidates[0] || null;
    return target?.closest("a,[onclick]") || target;
  }

  function pageInfo(stage = "") {
    return {
      role: role(),
      href: String(location.href || ""),
      title: String(document.title || ""),
      top: IS_TOP,
      canNavigate: Boolean(menuTarget(menuPatternFor(stage))),
    };
  }

  async function send(message) {
    return chrome.runtime.sendMessage({ ...message, version: VERSION }).catch(() => null);
  }

  async function waitFor(check, timeoutMs = 30_000, intervalMs = 250) {
    const deadline = Date.now() + timeoutMs;
    let lastError = null;
    while (Date.now() < deadline) {
      try {
        const value = await check();
        if (value) return value;
      } catch (error) {
        lastError = error;
      }
      await sleep(intervalMs);
    }
    if (lastError) throw lastError;
    return null;
  }

  function escapeRegex(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function exactTokenRegex(token) {
    return new RegExp(`(^|[^A-Z0-9-])${escapeRegex(norm(token).toUpperCase())}([^A-Z0-9-]|$)`, "i");
  }

  function clickDirect(element) {
    if (!element) return false;
    try {
      element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
      element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
      element.click();
      return true;
    } catch {
      return false;
    }
  }

  function clickViaMain(element) {
    return new Promise((resolve) => {
      if (!element) {
        resolve({ ok: false, code: "CLICK_TARGET_MISSING", alerts: [] });
        return;
      }
      const token = `stock-${Date.now()}-${Math.random().toString(16).slice(2)}`;
      element.setAttribute(MAIN_TOKEN_ATTRIBUTE, token);
      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        window.removeEventListener(MAIN_RESULT, listener);
        resolve(value);
      };
      const listener = (event) => {
        if (norm(event?.detail?.token) !== token) return;
        finish(event.detail || { ok: false, code: "MAIN_CLICK_EMPTY_RESULT" });
      };
      window.addEventListener(MAIN_RESULT, listener);
      window.dispatchEvent(new CustomEvent(MAIN_REQUEST, { detail: { token } }));
      window.setTimeout(() => finish({ ok: true, code: "MAIN_CLICK_NAVIGATED_OR_PENDING", alerts: [] }), 3500);
    });
  }

  function setInput(input, value) {
    if (!(input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement)) return false;
    const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), "value");
    if (descriptor?.set) descriptor.set.call(input, value);
    else input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return norm(input.value) === norm(value);
  }

  function setCheck(control, checked = true) {
    if (!(control instanceof HTMLInputElement)) return false;
    if (!["checkbox", "radio"].includes(control.type)) return false;
    if (control.checked !== checked) control.click();
    control.checked = checked;
    control.dispatchEvent(new Event("input", { bubbles: true }));
    control.dispatchEvent(new Event("change", { bubbles: true }));
    return control.checked === checked;
  }

  function selectByText(select, label, exact = false) {
    if (!(select instanceof HTMLSelectElement)) return false;
    const wanted = norm(label);
    const options = [...select.options];
    const option =
      options.find((item) => norm(item.textContent) === wanted) ||
      (!exact ? options.find((item) => norm(item.textContent).includes(wanted)) : null);
    if (!option) return false;
    select.value = option.value;
    select.dispatchEvent(new Event("input", { bubbles: true }));
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return select.value === option.value;
  }

  function selectWithOption(label) {
    const wanted = norm(label);
    return [...document.querySelectorAll("select")]
      .filter(visible)
      .filter((select) => [...select.options].some((option) => norm(option.textContent).includes(wanted)));
  }

  function editableSearchInputs(root = document) {
    return [...root.querySelectorAll("input,textarea")].filter((input) => {
      if (!(input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement)) return false;
      if (!visible(input) || input.disabled || input.readOnly) return false;
      if (input instanceof HTMLTextAreaElement) return true;
      const type = norm(input.getAttribute("type") || input.type || "text").toLowerCase();
      return ![
        "hidden",
        "button",
        "submit",
        "reset",
        "image",
        "checkbox",
        "radio",
        "file",
        "date",
        "month",
        "week",
        "time",
        "datetime-local",
        "color",
        "range",
        "number",
      ].includes(type);
    });
  }

  function findSearchInput(fieldSelect) {
    const row = fieldSelect?.closest("tr") || null;
    const form = fieldSelect?.form || null;
    const candidates = [
      ...(row ? editableSearchInputs(row) : []),
      ...(form ? editableSearchInputs(form) : []),
      ...editableSearchInputs(document),
    ].filter((input, index, all) => all.indexOf(input) === index);
    let best = null;
    let bestScore = -999;
    const fieldRect = fieldSelect?.getBoundingClientRect?.() || null;
    for (const input of candidates) {
      const context = localText(input);
      let score = 0;
      const inputRect = input.getBoundingClientRect();
      if (row && input.closest("tr") === row) score += 40;
      if (form && input.form === form) score += 8;
      if (/검색항목|다중검색|자사상품코드|옵션자체관리코드|모델번호|상품등록번호|샵플링상품코드|상품검색용코드|상품번호|상품키|goods key/i.test(context)) score += 18;
      if (/search|find|query|keyword|sch/i.test(`${input.name || ""} ${input.id || ""}`)) score += 8;
      if (/가격검색|일자|날짜/i.test(context)) score -= 25;
      if (/^20\d{6}$/.test(norm(input.value))) score -= 30;
      if (fieldRect) {
        const vertical = Math.abs(fieldRect.top - inputRect.top);
        if (vertical <= 18) score += 25;
        else score -= Math.min(25, vertical / 12);
        if (inputRect.left >= fieldRect.left) score += 6;
        score -= Math.min(12, Math.abs(inputRect.left - fieldRect.right) / 45);
      }
      if (score > bestScore) {
        best = input;
        bestScore = score;
      }
    }
    return bestScore >= 0 ? best : null;
  }

  function searchInputDiagnostics(fieldSelect) {
    const fieldRect = fieldSelect?.getBoundingClientRect?.() || null;
    return editableSearchInputs(document)
      .slice(0, 20)
      .map((input) => {
        const rect = input.getBoundingClientRect();
        return {
          tag: input.tagName,
          type: input instanceof HTMLInputElement ? norm(input.getAttribute("type") || input.type || "text") : "textarea",
          name: norm(input.name),
          id: norm(input.id),
          value: norm(input.value).slice(0, 80),
          context: localText(input).slice(0, 180),
          top: Math.round(rect.top),
          left: Math.round(rect.left),
          fieldTop: fieldRect ? Math.round(fieldRect.top) : null,
          fieldRight: fieldRect ? Math.round(fieldRect.right) : null,
        };
      });
  }

  function buttonByText(pattern, root = document) {
    const selector = 'button,input[type="button"],input[type="submit"],input[type="image"],a,[onclick],img[alt],img[title]';
    const candidates = [...root.querySelectorAll(selector)].filter(visible);
    const matches = candidates.filter((element) => pattern.test(controlText(element)));
    matches.sort((left, right) => controlText(left).length - controlText(right).length);
    const candidate = matches[0] || null;
    if (candidate instanceof HTMLImageElement) return candidate.closest("a,button,input,[onclick]") || candidate;
    return candidate;
  }

  function clickSearch(input) {
    const root = input?.form || input?.closest("table") || document;
    const candidates = [...root.querySelectorAll('button,input[type="button"],input[type="submit"],input[type="image"],a,[onclick]')]
      .filter((element) => visible(element) && /^검색$/.test(controlText(element)));
    if (!candidates.length) return false;
    const inputRect = input.getBoundingClientRect();
    candidates.sort((left, right) =>
      Math.abs(left.getBoundingClientRect().top - inputRect.top) - Math.abs(right.getBoundingClientRect().top - inputRect.top),
    );
    return clickDirect(candidates[0]);
  }

  function rowEvidenceTextV053(row) {
    const values = [row?.textContent || ""];
    for (const control of row?.querySelectorAll?.("input,textarea,select") || []) {
      if ("value" in control) values.push(control.value || "");
      if (control instanceof HTMLSelectElement) values.push(control.options?.[control.selectedIndex]?.textContent || "");
    }
    return norm(values.join(" "));
  }

  function matchingRows(token) {
    const regex = exactTokenRegex(token);
    return [...document.querySelectorAll("tr")]
      .map((row) => ({ row, evidenceText: rowEvidenceTextV053(row) }))
      .filter(({ evidenceText }) => regex.test(evidenceText.toUpperCase()))
      .map(({ row, evidenceText }) => ({ row, checkbox: row.querySelector('input[type="checkbox"]'), text: evidenceText }))
      .filter((entry) => entry.checkbox && !entry.checkbox.disabled);
  }

  function selectOnlyMatchingRows(token) {
    const matches = matchingRows(token);
    if (!matches.length) return { ok: false, count: 0, rows: [] };
    const resultRows = [...document.querySelectorAll("tr")].filter((row) => row.querySelector('input[type="checkbox"]'));
    for (const row of resultRows) {
      const checkbox = row.querySelector('input[type="checkbox"]');
      if (!checkbox || checkbox.disabled) continue;
      setCheck(checkbox, matches.some((entry) => entry.row === row));
    }
    const selected = matches.filter((entry) => entry.checkbox.checked);
    return { ok: selected.length === matches.length && selected.length > 0, count: selected.length, rows: matches };
  }

  function searchFieldV041(label) {
    const candidates = selectWithOption(label).map((select, index) => {
      const labels = [...select.options].map((option) => norm(option.textContent));
      const row = select.closest("tr");
      const context = norm(row?.textContent || select.parentElement?.textContent || "");
      const localInputs = row
        ? [...row.querySelectorAll('input[type="text"], input:not([type]), input[type="search"]')].filter(visible)
        : [];
      let score = 0;
      if (labels.includes(label)) score += 80;
      if (labels.includes("검색항목")) score += 220;
      if (/검색\s*항목/.test(context)) score += 180;
      if (localInputs.length) score += 120;
      if (/화면출력|내림차순|오름차순/.test(context)) score -= 500;
      return { select, index, score };
    });
    candidates.sort((left, right) => right.score - left.score || left.index - right.index);
    const best = candidates[0] || null;
    return best && best.score >= 200 ? best.select : null;
  }

  function searchInputV041(field) {
    const row = field?.closest("tr");
    if (!row) return null;
    const fieldRect = field.getBoundingClientRect();
    const inputs = [...row.querySelectorAll('input[type="text"], input:not([type]), input[type="search"]')]
      .filter((input) => visible(input) && !input.disabled)
      .map((input, index) => {
        const rect = input.getBoundingClientRect();
        let score = 0;
        if (rect.left >= fieldRect.right - 8) score += 120;
        score += Math.max(0, 80 - Math.abs(rect.top - fieldRect.top) * 4);
        score += Math.min(80, rect.width / 4);
        return { input, index, score };
      })
      .sort((left, right) => right.score - left.score || left.index - right.index);
    return inputs[0]?.input || null;
  }

  async function searchExact(fieldLabel, token) {
    return globalThis.CommerceStockSearchV023.search(fieldLabel, token, {
      scope: [executionContext.jobId, executionContext.executionId, executionContext.stage].join(":"),
      getField: searchFieldV041,
      selectField: selectByText, findInput: searchInputV041, setInput,
      clickSearch, rows: matchingRows, waitFor, sleep,
      resultCount: () => {
        const match = bodyText().match(/총\s*조회수\s*[:：]?\s*([\d,]+)\s*건/i);
        return match ? Number(match[1].replace(/,/g, "")) : null;
      },
    });
  }  async function searchGoodsKey(goodsKey) {
    const labels = ["샵플링상품코드", "상품등록번호", "상품검색용코드", "상품번호", "상품키", "Goods Key", "goods key"];
    for (const label of labels) {
      if (!selectWithOption(label).length) continue;
      const result = await searchExact(label, goodsKey);
      if (result.ok) return result;
      if (!["SEARCH_FIELD_NOT_FOUND"].includes(result.code)) return result;
    }
    return {
      ok: false,
      code: "GOODS_KEY_SEARCH_FIELD_NOT_FOUND",
      message: `goods key ${goodsKey} 검색용 항목을 찾지 못했습니다.`,
    };
  }

  async function navigateTo(target) {
    const element = menuTarget(menuPatternFor(target));
    if (!element || !clickDirect(element)) {
      return { ok: false, code: "SHOPLING_MENU_NOT_FOUND", message: `${target} 메뉴를 찾지 못했습니다.` };
    }
    return { ok: true, navigating: true, message: `${target} 화면으로 이동 중입니다.` };
  }

  function desiredKorean(status) {
    return status === "SOLD_OUT" ? "품절" : "판매중";
  }

  function alertFailure(alerts) {
    const message = norm((alerts || []).join(" "));
    if (!message) return null;
    if (/실패|오류|불가|없습니다|선택해|확인해|잘못/i.test(message)) return message;
    return null;
  }

  function a6ControlTextHF19(element) {
    if (!element) return "";
    const values = [element.textContent, element.value, element.title, element.alt, element.name, element.id, element.getAttribute?.("aria-label")];
    for (const image of element.querySelectorAll?.("img[alt],img[title]") || []) values.push(image.getAttribute("alt") || "", image.getAttribute("title") || "");
    return norm(values.filter(Boolean).join(" "));
  }

  function setA6MaxPageSizeHF19() {
    const ranked = [...document.querySelectorAll("select")].map((select, index) => {
      const options = [...select.options].map((option) => ({ option, label: norm(option.textContent), value: Number(norm(option.textContent).replace(/[^0-9]/g, "")) }));
      const standardHits = options.filter((row) => [25, 50, 100, 200, 500, 1000].includes(row.value)).length;
      const context = norm(select.closest("tr")?.textContent || select.parentElement?.textContent || "");
      let score = standardHits * 80;
      if (/화면출력|출력수|페이지당|page\s*size/i.test(context)) score += 600;
      if (standardHits < 2) score -= 800;
      const numeric = options.filter((row) => Number.isInteger(row.value) && row.value > 0 && row.value <= 5000);
      const maxValue = numeric.length ? Math.max(...numeric.map((row) => row.value)) : 0;
      return { select, options, maxValue, score, index };
    }).sort((left, right) => right.score - left.score || left.index - right.index);
    const candidate = ranked[0];
    if (!candidate || candidate.score < 200 || candidate.maxValue <= 0) {
      return { ok: false, code: "A6_MAX_PAGE_SIZE_NOT_FOUND", message: "A6 화면출력 드롭다운의 최대값을 안전하게 찾지 못했습니다." };
    }
    const target = candidate.options.find((row) => row.value === candidate.maxValue)?.option;
    if (!target) return { ok: false, code: "A6_MAX_PAGE_SIZE_OPTION_MISSING", message: "A6 최대 화면출력 옵션을 찾지 못했습니다." };
    if (candidate.select.value !== target.value) {
      candidate.select.value = target.value;
      candidate.select.dispatchEvent(new Event("input", { bubbles: true }));
      candidate.select.dispatchEvent(new Event("change", { bubbles: true }));
    }
    const selected = Number(norm(candidate.select.options?.[candidate.select.selectedIndex]?.textContent).replace(/[^0-9]/g, ""));
    return selected === candidate.maxValue
      ? { ok: true, pageSize: candidate.maxValue }
      : { ok: false, code: "A6_MAX_PAGE_SIZE_VERIFY_FAILED", message: "A6 최대 화면출력 설정이 유지되지 않았습니다.", evidence: { expected: candidate.maxValue, selected } };
  }

  function a6RowEvidenceTextHF19(row) {
    const values = [row?.textContent || ""];
    for (const control of row?.querySelectorAll?.("input,textarea,select") || []) {
      if ("value" in control) values.push(control.value || "");
      if (control instanceof HTMLSelectElement) values.push(control.options?.[control.selectedIndex]?.textContent || "");
    }
    return norm(values.join(" "));
  }

  function a6IdentityPairHF33(row, text) {
    const checkbox = row?.querySelector?.('input[name="chk[]"]') || row?.querySelector?.('input[type="checkbox"][value*="_"]');
    const checkboxValue = String(checkbox?.value || "").trim();
    const checkboxMatch = checkboxValue.match(/^(\d{4,})_(\d{4,})$/);
    if (checkboxMatch) return { goodsKey: checkboxMatch[1], optionId: checkboxMatch[2], source: "CHECKBOX_VALUE" };
    const textMatch = String(text || "").match(/(^|[^0-9])(\d{4,})-(\d{4,})(?=[^0-9]|$)/);
    return textMatch ? { goodsKey: textMatch[2], optionId: textMatch[3], source: "ROW_TEXT" } : null;
  }

  function a6RowsFromDocumentHF19(doc, barcode) {
    const barcodeRegex = exactTokenRegex(barcode);
    return [...doc.querySelectorAll("tr")]
      .map((row) => {
        const text = a6RowEvidenceTextHF19(row);
        const resultCheckbox = row?.querySelector?.('input[name="chk[]"]') || row?.querySelector?.('input[type="checkbox"]');
        return { row, text, identity: a6IdentityPairHF33(row, text), resultCheckbox };
      })
      .filter(({ text, identity, resultCheckbox }) => Boolean(resultCheckbox) && Boolean(identity) && barcodeRegex.test(text.toUpperCase()));
  }

  function a6TotalFromDocumentHF19(doc) {
    const text = norm(doc.body?.innerText || doc.body?.textContent || doc.documentElement?.textContent || "");
    const match = text.match(/총\s*조회수\s*[:：]?\s*([\d,]+)\s*건/i);
    return match ? Number(match[1].replace(/,/g, "")) : null;
  }

  function a6NextPageHrefHF19(doc, nextPageNumber, baseHref) {
    const ranked = [];
    for (const anchor of doc.querySelectorAll("a[href]")) {
      const rawHref = String(anchor.getAttribute("href") || "").trim();
      if (!rawHref || rawHref === "#" || /^javascript:/i.test(rawHref)) continue;
      let url = null;
      try { url = new URL(rawHref, baseHref || location.href); } catch { continue; }
      if (url.origin !== location.origin || url.href === (baseHref || location.href)) continue;
      const label = norm([anchor.textContent, anchor.title, anchor.getAttribute("aria-label"), ...[...anchor.querySelectorAll("img[alt],img[title]")].flatMap((img) => [img.getAttribute("alt"), img.getAttribute("title")])].filter(Boolean).join(" "));
      const hrefEvidence = [url.pathname, url.search, anchor.getAttribute("onclick") || "", anchor.id || "", anchor.className || ""].join(" ");
      let score = 0;
      if (/^(다음|다음페이지|next|>|›|»|≫|▶)$/i.test(label)) score += 1000;
      if (/page|pageno|page_no|pageNum|pg=|curpage|nowpage/i.test(hrefEvidence)) score += 500;
      if (/^\d+$/.test(label) && Number(label) === nextPageNumber) score += 700;
      if (/검색|수정|송신|상품명|goods/i.test(label)) score -= 1000;
      ranked.push({ href: url.href, score });
    }
    ranked.sort((left, right) => right.score - left.score);
    return ranked[0]?.score >= 900 ? ranked[0].href : null;
  }

  async function collectAllA6RowsHF19(job, firstRows, totalResultCount, pageSize) {
    if (!Number.isInteger(totalResultCount) || totalResultCount <= firstRows.length) return { ok: true, rows: firstRows, pages: 1 };
    const rows = [...firstRows];
    const visited = new Set([location.href]);
    const pageFingerprints = new Set([firstRows.map((entry) => entry.text).join("||")]);
    let currentDoc = document;
    let currentHref = location.href;
    let pageNumber = 1;
    while (rows.length < totalResultCount && pageNumber < 100) {
      const nextHref = a6NextPageHrefHF19(currentDoc, pageNumber + 1, currentHref);
      if (!nextHref || visited.has(nextHref)) {
        return { ok: false, code: "A6_PAGINATION_NEXT_NOT_FOUND", message: String(job.barcode) + " A6 조회 " + totalResultCount + "건 중 " + rows.length + "건을 읽은 뒤 다음 페이지 링크를 안전하게 특정하지 못했습니다. 부분처리는 하지 않습니다.", evidence: { totalResultCount, matchedRows: rows.length, pageSize, pagesRead: pageNumber, paginationRequired: true } };
      }
      visited.add(nextHref);
      const response = await fetch(nextHref, { method: "GET", credentials: "include", cache: "no-store" }).catch(() => null);
      if (!response?.ok) {
        return { ok: false, code: "A6_PAGINATION_FETCH_FAILED", message: String(job.barcode) + " A6 다음 페이지를 읽지 못했습니다. 부분처리는 하지 않습니다.", evidence: { nextHref, status: response?.status || null, totalResultCount, matchedRows: rows.length, pageSize, pagesRead: pageNumber } };
      }
      const html = await response.text();
      const nextDoc = new DOMParser().parseFromString(html, "text/html");
      const nextRows = a6RowsFromDocumentHF19(nextDoc, job.barcode);
      const nextTotal = a6TotalFromDocumentHF19(nextDoc);
      if (Number.isInteger(nextTotal) && nextTotal !== totalResultCount) {
        return { ok: false, code: "A6_PAGINATION_TOTAL_CHANGED", message: String(job.barcode) + " A6 페이지 이동 중 총 조회수가 변경되어 부분처리를 차단했습니다.", evidence: { expectedTotal: totalResultCount, nextTotal, nextHref, pagesRead: pageNumber } };
      }
      if (!nextRows.length) {
        return { ok: false, code: "A6_PAGINATION_EMPTY_PAGE", message: String(job.barcode) + " A6 다음 페이지에서 정확 B코드 행을 찾지 못해 부분처리를 차단했습니다.", evidence: { nextHref, totalResultCount, matchedRows: rows.length, pagesRead: pageNumber } };
      }
      const fingerprint = nextRows.map((entry) => entry.text).join("||");
      if (pageFingerprints.has(fingerprint)) {
        return { ok: false, code: "A6_PAGINATION_DUPLICATE_PAGE", message: String(job.barcode) + " A6 다음 페이지 응답이 이미 읽은 페이지와 같아 부분처리를 차단했습니다.", evidence: { nextHref, totalResultCount, matchedRows: rows.length, pagesRead: pageNumber } };
      }
      pageFingerprints.add(fingerprint);
      rows.push(...nextRows);
      pageNumber += 1;
      currentDoc = nextDoc;
      currentHref = nextHref;
      if (rows.length > totalResultCount) {
        return { ok: false, code: "A6_PAGINATION_ROW_OVERFLOW", message: String(job.barcode) + " A6 페이지 합산 행 수가 총 조회수보다 커져 부분처리를 차단했습니다.", evidence: { totalResultCount, matchedRows: rows.length, pagesRead: pageNumber } };
      }
    }
    if (rows.length !== totalResultCount) {
      return { ok: false, code: "A6_PAGINATION_INCOMPLETE", message: String(job.barcode) + " A6 전체 페이지 수집이 완료되지 않아 부분처리를 차단했습니다.", evidence: { totalResultCount, matchedRows: rows.length, pageSize, pagesRead: pageNumber } };
    }
    return { ok: true, rows, pages: pageNumber };
  }

  function clearA6DateScopeHF31() {
    const form = document.forms?.frm || document.querySelector('form[action*="prodBulkOptLst"]');
    const start = form?.querySelector('input[name="s_dt"]');
    const end = form?.querySelector('input[name="e_dt"]');
    if (!(form instanceof HTMLFormElement) || !(start instanceof HTMLInputElement) || !(end instanceof HTMLInputElement)) {
      return { ok: false, code: "A6_DATE_SCOPE_CONTROLS_NOT_FOUND", message: "A6 상품등록기간 입력칸(s_dt/e_dt)을 찾지 못했습니다." };
    }
    const previousDateRange = { start: start.value, end: end.value };
    const todayKst = new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Seoul", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date()).replace(/-/g, "");
    const expectedDateRange = { start: "20230101", end: todayKst };
    for (const [input, value] of [[start, expectedDateRange.start], [end, expectedDateRange.end]]) {
      input.value = value;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    }
    const currentDateRange = { start: start.value, end: end.value };
    if (currentDateRange.start !== expectedDateRange.start || currentDateRange.end !== expectedDateRange.end) {
      return { ok: false, code: "A6_DATE_SCOPE_SET_FAILED", message: "A6 상품등록기간을 2023-01-01부터 오늘까지 설정하지 못했습니다.", evidence: { previousDateRange, expectedDateRange, currentDateRange } };
    }
    return { ok: true, dateScope: "2023_TO_TODAY", previousDateRange, currentDateRange };
  }

  async function runA6(job) {
    if (role() !== "A6") return navigateTo("A6");
    const pageSize = setA6MaxPageSizeHF19();
    if (!pageSize.ok) return pageSize;
    const dateScope = clearA6DateScopeHF31();
    if (!dateScope.ok) return dateScope;
    await sleep(120);
    const search = await searchExact("옵션자체관리코드", job.barcode);
    if (!search.ok) return search;

    const firstRows = a6RowsFromDocumentHF19(document, job.barcode);
    const totalResultCount = a6TotalFromDocumentHF19(document);
    if (!firstRows.length) {
      return { ok: false, code: "A6_BCODE_RESULT_ROW_NOT_FOUND", message: String(job.barcode) + "를 2023-01-01~오늘 범위에서 검색했지만 정확히 연결된 상품 행을 찾지 못했습니다.", evidence: { totalResultCount, matchedRows: 0, pageSize: pageSize.pageSize, readOnly: true } };
    }
    if (!Number.isInteger(totalResultCount) && firstRows.length >= pageSize.pageSize) {
      return { ok: false, code: "A6_RESULT_COUNT_UNKNOWN_AT_PAGE_LIMIT", message: String(job.barcode) + " A6 총 조회수를 확인하지 못했고 현재 화면이 최대 " + pageSize.pageSize + "건으로 가득 차 다음 페이지 가능성을 배제할 수 없어 중단했습니다.", evidence: { matchedRows: firstRows.length, pageSize: pageSize.pageSize, readOnly: true, paginationRequired: true } };
    }

    const collected = await collectAllA6RowsHF19(job, firstRows, totalResultCount, pageSize.pageSize);
    if (!collected.ok) return collected;
    const allResultRows = collected.rows;
    if (Number.isInteger(totalResultCount) && totalResultCount > 0 && allResultRows.length !== totalResultCount) {
      return { ok: false, code: "A6_RESULT_PAGE_INCOMPLETE", message: String(job.barcode) + " A6 조회 " + totalResultCount + "건 중 상품코드 행 " + allResultRows.length + "건만 읽혀 일부 누락 위험 때문에 중단했습니다.", evidence: { totalResultCount, matchedRows: allResultRows.length, pageSize: pageSize.pageSize, pagesRead: collected.pages, readOnly: true } };
    }
    const resultRows = allResultRows;


    const discoveredPairs = [];
    for (const entry of resultRows) {
      const pair = a6IdentityPairHF33(entry.row, entry.text);
      if (pair) discoveredPairs.push({ ...pair, rowText: entry.text.slice(0, 500) });
    }
    const discoveredGoodsKeys = [...new Set(discoveredPairs.map((pair) => pair.goodsKey).filter((value) => /^\d+$/.test(value)))].sort((a, b) => Number(a) - Number(b));
    if (!discoveredGoodsKeys.length) {
      return { ok: false, code: "A6_BCODE_GOODSKEY_NOT_FOUND", message: String(job.barcode) + " 검색결과에서 Shopling 상품코드를 읽지 못했습니다.", evidence: { totalResultCount, matchedRows: resultRows.length, pageSize: pageSize.pageSize, pagesRead: collected.pages, readOnly: true } };
    }

    return {
      ok: true,
      completed: true,
      message: String(job.barcode) + " A6 읽기전용 조회 완료 · 최대 화면출력 " + pageSize.pageSize + "개 · " + collected.pages + "페이지 · 상품코드 " + discoveredGoodsKeys.length + "건: " + discoveredGoodsKeys.join(", "),
      evidence: {
        discoveredGoodsKeys,
        discoveredPairs,
        goodsKeyCount: discoveredGoodsKeys.length,
        goodsKeySource: "A6_LIVE_OPTION_BARCODE",
        matchedRows: resultRows.length,
        totalResultCount,
        pageSize: pageSize.pageSize,
        pagesRead: collected.pages,
        paginationMode: collected.pages > 1 ? "SAME_ORIGIN_FETCH_ALL_PAGES" : "SINGLE_PAGE",
        readOnly: true,
        checkboxTouched: false,
        optionStatusTouched: false,
      },
    };
  }

  async function runA4(job, goodsKey) {
    if (role() !== "A4") return navigateTo("A4");
    if (!goodsKey) return { ok: false, code: "A4_GOODS_KEY_REQUIRED", message: "A4 검색용 goods key가 없습니다." };
    const search = await searchGoodsKey(goodsKey);
    if (!search.ok) return search;
    const selected = selectOnlyMatchingRows(goodsKey);
    if (!selected.ok || selected.count !== 1) {
      return { ok: false, code: "A4_EXACT_ROW_SELECTION_FAILED", message: `${goodsKey} A4 정확 일치 행 1건을 단독 선택하지 못했습니다.`, evidence: { selectedCount: selected.count, searchField: search.fieldLabel } };
    }
    const targetLabel = desiredKorean(job.desiredStatus);
    const selects = statusSelectCandidates();
    let statusSelect = selects[0] || null;
    if (statusSelect) {
      const rowRect = selected.rows[0].row.getBoundingClientRect();
      selects.sort((left, right) => Math.abs(left.getBoundingClientRect().top - rowRect.top) - Math.abs(right.getBoundingClientRect().top - rowRect.top));
      statusSelect = selects[0] || statusSelect;
      if (!selectByText(statusSelect, targetLabel, true)) {
        return { ok: false, code: "A4_TARGET_STATUS_NOT_FOUND", message: `A4 상품상태 ${targetLabel} 선택값을 찾지 못했습니다.` };
      }
      const button = buttonByText(/^(?:상품|판매)?\s*상태\s*변경$|^일괄\s*상태변경$/i);
      if (!button) {
        return { ok: false, code: "A4_STATUS_CHANGE_BUTTON_NOT_FOUND", message: "A4 상품상태 변경 버튼을 찾지 못했습니다." };
      }
      const click = await clickViaMain(button);
      const failure = alertFailure(click.alerts);
      if (!click.ok || failure) {
        return { ok: false, code: "A4_STATUS_CHANGE_REJECTED", message: failure || click.message || "A4 상품상태 변경이 거절됐습니다.", evidence: click };
      }
    } else {
      const row = selected.rows[0].row;
      const direct = rowLocalButton(row, new RegExp(`^${escapeRegex(targetLabel)}$`, "i"));
      if (!direct) {
        return {
          ok: false,
          code: "A4_PRODUCT_STATUS_CONTROL_NOT_FOUND",
          message: `A4에서 ${goodsKey} 상품의 품절/판매중 전환 컨트롤을 안전하게 특정하지 못했습니다.`,
          evidence: { searchField: search.fieldLabel, rowSample: selected.rows[0].text.slice(0, 500) },
        };
      }
      const click = await clickViaMain(direct);
      const failure = alertFailure(click.alerts);
      if (!click.ok || failure) {
        return { ok: false, code: "A4_STATUS_CHANGE_REJECTED", message: failure || click.message || "A4 상품상태 변경이 거절됐습니다.", evidence: click };
      }
    }
    const verified = await waitFor(() => {
      const rows = matchingRows(goodsKey);
      if (!rows.length) return null;
      if (rows.every((entry) => new RegExp(`(^|\\s)${escapeRegex(targetLabel)}($|\\s)`).test(entry.text))) return rows;
      if (/변경.*완료|정상.*처리|수정.*완료/i.test(bodyText())) return rows;
      return null;
    }, 20_000, 500);
    if (!verified) {
      return { ok: false, uncertain: true, code: "A4_STATUS_CHANGE_UNVERIFIED", message: `A4 ${goodsKey} 상품상태 ${targetLabel} 요청 후 결과를 확정하지 못했습니다.`, evidence: { selectedRows: selected.count } };
    }
    return { ok: true, completed: true, step: "A4", message: `A4 goods key ${goodsKey} 상품상태를 ${targetLabel}로 확인했습니다.`, evidence: { goodsKey, targetLabel, searchField: search.fieldLabel } };
  }

  function setA21PageSize200V042() {
    const candidate = [...document.querySelectorAll("select")].find((select) => {
      const labels = [...select.options].map((option) => norm(option.textContent));
      return labels.includes("200") && (labels.includes("25") || labels.includes("50") || labels.includes("100") || labels.includes("500"));
    });
    if (!candidate) return { ok: false, code: "A21_PAGE_SIZE_200_NOT_FOUND", message: "A21 화면출력 200개 선택값을 찾지 못했습니다." };
    const current = norm(candidate.options?.[candidate.selectedIndex]?.textContent);
    if (current !== "200" && !selectByText(candidate, "200", true)) return { ok: false, code: "A21_PAGE_SIZE_200_SET_FAILED", message: "A21 화면출력을 200개로 변경하지 못했습니다." };
    return norm(candidate.options?.[candidate.selectedIndex]?.textContent) === "200"
      ? { ok: true }
      : { ok: false, code: "A21_PAGE_SIZE_200_VERIFY_FAILED", message: "A21 화면출력 200개 설정이 유지되지 않았습니다." };
  }

  function a21TotalResultCountV042() {
    const match = bodyText().match(/총\s*조회수\s*[:：]?\s*([\d,]+)\s*건/i);
    return match ? Number(match[1].replace(/,/g, "")) : null;
  }

  function a21RowsForHeaderSelectV057(goodsKey) {
    const bound = matchingRows(goodsKey).map((entry) => {
      const boxes = [...entry.row.querySelectorAll('input[type="checkbox"]')].filter((box) => !box.disabled);
      const checkbox = boxes.find((box) => visible(box)) || entry.checkbox || boxes[0] || null;
      return { ...entry, checkbox };
    }).filter((entry) => entry.checkbox);
    const visibleBound = bound.filter((entry) => visible(entry.row) || visible(entry.checkbox));
    return visibleBound.length ? visibleBound : bound;
  }

  function a21HeaderCheckboxV057(exactRows) {
    if (!exactRows.length) return null;
    const tableGroups = new Map();
    for (const entry of exactRows) {
      const table = entry.row.closest("table");
      if (!table) continue;
      if (!tableGroups.has(table)) tableGroups.set(table, []);
      tableGroups.get(table).push(entry);
    }
    const ranked = [];
    for (const [table, entries] of tableGroups.entries()) {
      const rowBoxes = new Set(entries.map((entry) => entry.checkbox));
      const firstRect = entries[0].checkbox.getBoundingClientRect();
      const minTop = Math.min(...entries.map((entry) => entry.checkbox.getBoundingClientRect().top));
      for (const checkbox of table.querySelectorAll('input[type="checkbox"]')) {
        if (!(checkbox instanceof HTMLInputElement) || checkbox.disabled || rowBoxes.has(checkbox)) continue;
        const rect = checkbox.getBoundingClientRect();
        const row = checkbox.closest("tr");
        const label = norm([checkbox.name || "", checkbox.id || "", checkbox.className || "", checkbox.getAttribute("onclick") || "", row?.textContent || ""].join(" "));
        let score = entries.length * 1000;
        if (checkbox.closest("thead") || checkbox.closest("th")) score += 5000;
        if (rect.top <= minTop) score += 2000;
        score += Math.max(0, 1000 - Math.abs(rect.left - firstRect.left) * 20);
        if (/전체|all|check|select/i.test(label)) score += 800;
        ranked.push({ checkbox, score });
      }
    }
    ranked.sort((left, right) => right.score - left.score);
    return ranked[0]?.checkbox || null;
  }

  async function selectA21HeaderAllV057(exactRows, expectedCount) {
    const master = a21HeaderCheckboxV057(exactRows);
    if (!master) {
      return { ok: false, code: "A21_HEADER_SELECT_ALL_NOT_FOUND", count: 0, rows: exactRows, selectionMode: "SHOPLING_HEADER_SELECT_ALL" };
    }
    const selectedCount = () => exactRows.filter((entry) => entry.checkbox.checked).length;
    if (selectedCount() === expectedCount) {
      return { ok: true, count: expectedCount, rows: exactRows, selectionMode: "SHOPLING_HEADER_SELECT_ALL_ALREADY" };
    }
    if (master.checked) {
      if (!clickDirect(master)) return { ok: false, code: "A21_HEADER_SELECT_ALL_RESET_FAILED", count: selectedCount(), rows: exactRows, selectionMode: "SHOPLING_HEADER_SELECT_ALL" };
      await sleep(120);
    }
    if (!clickDirect(master)) return { ok: false, code: "A21_HEADER_SELECT_ALL_CLICK_FAILED", count: selectedCount(), rows: exactRows, selectionMode: "SHOPLING_HEADER_SELECT_ALL" };
    await sleep(220);
    const count = selectedCount();
    if (count !== expectedCount) {
      return { ok: false, code: "A21_HEADER_SELECT_ALL_VERIFY_FAILED", count, rows: exactRows, selectionMode: "SHOPLING_HEADER_SELECT_ALL", masterChecked: Boolean(master.checked) };
    }
    return { ok: true, count, rows: exactRows, selectionMode: "SHOPLING_HEADER_SELECT_ALL", masterChecked: Boolean(master.checked) };
  }

  async function runA21List(job, goodsKey) {
    if (role() !== "A21_LIST") return navigateTo("A21_LIST");
    if (!goodsKey) return { ok: false, code: "A21_GOODS_KEY_REQUIRED", message: "A21 검색용 goods key가 없습니다." };
    const pageSize = setA21PageSize200V042();
    if (!pageSize.ok) return pageSize;
    const search = await searchGoodsKey(goodsKey);
    if (!search.ok) return search;
    const reportedResultCount = a21TotalResultCountV042();
    const exactRows = a21RowsForHeaderSelectV057(goodsKey);
    if (!exactRows.length) return { ok: false, code: "A21_EXACT_RESULT_ROWS_NOT_FOUND", message: `${goodsKey} A21 정확 goods key 행을 찾지 못했습니다.`, evidence: { reportedResultCount, boundRowCount: 0, searchField: search.fieldLabel } };
    const reportedCountAvailable = Number.isInteger(reportedResultCount) && reportedResultCount > 0;
    if (reportedCountAvailable && reportedResultCount > 200) return { ok: false, code: "A21_RESULT_OVER_200_BATCH_LIMIT", message: `${goodsKey} A21 조회결과가 ${reportedResultCount}건으로 200건을 초과해 부분 전송을 차단했습니다.`, evidence: { reportedResultCount, boundRowCount: exactRows.length, batchLimit: 200, searchField: search.fieldLabel } };
    if (!reportedCountAvailable && exactRows.length >= 200) return { ok: false, code: "A21_RESULT_COUNT_UNAVAILABLE_AT_BATCH_LIMIT", message: `${goodsKey} A21 총 조회건수 문구가 없고 정확 행이 200건에 도달해 다음 페이지 가능성을 배제할 수 없어 전송을 차단했습니다.`, evidence: { reportedResultCount, boundRowCount: exactRows.length, batchLimit: 200, searchField: search.fieldLabel } };
    const totalResultCount = reportedCountAvailable ? reportedResultCount : exactRows.length;
    const resultCountSource = reportedCountAvailable ? "SHOPLING_TOTAL_TEXT" : "EXACT_BOUND_ROWS";
    if (exactRows.length !== totalResultCount) return { ok: false, code: "A21_EXACT_ROW_BINDING_MISMATCH", message: `${goodsKey} A21 조회 ${totalResultCount}건과 실제 연결된 행 ${exactRows.length}건이 달라 전체선택을 차단했습니다.`, evidence: { totalResultCount, reportedResultCount, resultCountSource, boundRowCount: exactRows.length, batchLimit: 200, searchField: search.fieldLabel } };
    const selected = (() => {
      let count = 0;
      const failures = [];
      for (const entry of exactRows) {
        const checkbox = entry.checkbox;
        const ok = setCheck(checkbox, true);
        if (ok && checkbox.checked) count += 1;
        else failures.push(norm(entry.text).slice(0, 180));
      }
      return { ok: count === totalResultCount, count, rows: exactRows, selectionMode: "PROVEN_PRICE_ROW_CHECKBOX_DIRECT", failures };
    })();
    if (!selected.ok || selected.count !== totalResultCount) return { ok: false, code: "A21_PRICE_ROW_CHECKBOX_VERIFY_FAILED", message: `${goodsKey} A21 가격조정 확장 방식으로 ${totalResultCount}건 중 ${selected.count}건만 체크되어 전송을 차단했습니다.`, evidence: { selectedCount: selected.count, totalResultCount, reportedResultCount, resultCountSource, boundRowCount: exactRows.length, batchLimit: 200, searchField: search.fieldLabel, selectionMode: selected.selectionMode, failures: selected.failures } };
    function a21CanonicalTextV056(element) {
      if (!element) return "";
      const values = [
        element.textContent,
        element.value,
        element.title,
        element.alt,
        element.name,
        element.id,
        element.getAttribute?.("aria-label"),
        element.getAttribute?.("onclick"),
      ];
      for (const image of element.querySelectorAll?.("img[alt],img[title]") || []) {
        values.push(image.getAttribute("alt") || "", image.getAttribute("title") || "");
      }
      return norm(values.filter(Boolean).join(" "));
    }

    function a21AccessibleDocumentsV056() {
      const scopes = [];
      const seen = new Set();
      const add = (doc, path) => {
        if (!doc || seen.has(doc)) return;
        seen.add(doc);
        scopes.push({ doc, path });
      };
      add(document, "self");
      const visit = (frame, path) => {
        let doc = null;
        try {
          doc = frame.document;
          void doc.documentElement;
        } catch {
          return;
        }
        add(doc, path);
        let count = 0;
        try { count = frame.frames.length; } catch {}
        for (let index = 0; index < count; index += 1) {
          try { visit(frame.frames[index], `${path}.${index}`); } catch {}
        }
      };
      try { visit(window.top, "top"); } catch {}
      return scopes;
    }

    function a21ClickableTargetV056(node) {
      if (!node) return null;
      const selector = 'button,input[type="button"],input[type="submit"],input[type="image"],a,[onclick]';
      if (node.matches?.(selector)) return node;
      return node.closest?.("a,button,input,[onclick]") || null;
    }

    function a21ClickCanonicalModifySendV056() {
      const scopes = a21AccessibleDocumentsV056();
      const diagnostics = [];
      const selector = 'button,input[type="button"],input[type="submit"],input[type="image"],a,[onclick],img[alt],img[title]';
      for (const scope of scopes) {
        const candidates = [];
        const push = (node) => {
          const button = a21ClickableTargetV056(node);
          if (button && !candidates.includes(button)) candidates.push(button);
        };
        for (const node of scope.doc.querySelectorAll(selector)) {
          if (/상품\s*수정전송/.test(a21CanonicalTextV056(node))) push(node);
        }
        if (!candidates.length) {
          for (const node of scope.doc.querySelectorAll("span,div,td,th")) {
            const label = norm(node.textContent || "");
            if (!/상품\s*수정전송/.test(label) || label.length > 80) continue;
            const button = node.closest?.("a,button,input,[onclick]") || node.querySelector?.("a,button,input,[onclick]") || null;
            if (button && !candidates.includes(button)) candidates.push(button);
          }
        }
        diagnostics.push({ framePath: scope.path, candidateCount: candidates.length });
        const button = candidates[0] || null;
        if (!button) continue;
        try {
          const view = button.ownerDocument?.defaultView || window;
          const Mouse = view?.MouseEvent || MouseEvent;
          button.dispatchEvent(new Mouse("mousedown", { bubbles: true, cancelable: true, view }));
          button.dispatchEvent(new Mouse("mouseup", { bubbles: true, cancelable: true, view }));
          button.click();
          return {
            ok: true,
            code: "PROVEN_A21_LIST_DIRECT_CLICK_CANONICAL_CROSS_FRAME",
            clickMode: "CANONICAL_PRICE_EXTENSION_CURRENT_THEN_ACCESSIBLE_FRAMES",
            framePath: scope.path,
            scannedDocuments: scopes.length,
            diagnostics,
            alerts: [],
          };
        } catch (error) {
          diagnostics.push({ framePath: scope.path, clickError: String(error?.message || error) });
        }
      }
      return {
        ok: false,
        code: "A21_MODIFY_SEND_BUTTON_NOT_FOUND",
        clickMode: "CANONICAL_PRICE_EXTENSION_CURRENT_THEN_ACCESSIBLE_FRAMES",
        scannedDocuments: scopes.length,
        diagnostics,
        alerts: [],
      };
    }

    const click = a21ClickCanonicalModifySendV056();
    if (!click.ok) {
      return {
        ok: false,
        code: "A21_MODIFY_SEND_BUTTON_NOT_FOUND",
        message: `A21 접근 가능한 ${click.scannedDocuments}개 frame에서 상품 수정전송 버튼을 찾지 못했습니다.`,
        evidence: click,
      };
    }
    return { ok: true, submitted: true, step: "A21_LIST_SUBMITTED", message: `A21 goods key ${goodsKey} 개별행 체크 ${selected.count}건 → 상품 수정전송 팝업을 열었습니다.`, evidence: { goodsKey, selectedRows: selected.count, totalResultCount, batchLimit: 200, searchField: search.fieldLabel, selectionMode: selected.selectionMode, alerts: click.alerts } };
  }

  function radioByAdjacentText(pattern) {
    const candidates = [...document.querySelectorAll('input[type="radio"],input[type="checkbox"]')]
      .filter(visible)
      .filter((control) => pattern.test(compact(localText(control))));
    candidates.sort((left, right) => localText(left).length - localText(right).length);
    return candidates[0] || null;
  }

  async function runA21Popup(job, goodsKey) {
    if (role() !== "A21_POPUP") {
      return { ok: false, waiting: true, code: "A21_POPUP_WAIT", message: "A21 수정전송 팝업 생성을 기다립니다." };
    }
    const targetLabel = desiredKorean(job.desiredStatus);
    let mode = null;
    let target = null;
    if (job.productKind === "OPTION") {
      mode = radioByAdjacentText(/상품옵션(?:송신|전송)|옵션(?:송신|전송)/i);
      if (!mode || !setCheck(mode, true)) {
        return { ok: false, code: "A21_OPTION_SEND_MODE_NOT_FOUND", message: "A21 옵션송신 모드를 선택하지 못했습니다." };
      }
    } else {
      mode = radioByAdjacentText(/상품판매상태송신/i);
      if (!mode || !setCheck(mode, true)) {
        return { ok: false, code: "A21_SALE_STATUS_MODE_NOT_FOUND", message: "A21 상품판매상태송신 모드를 선택하지 못했습니다." };
      }
      target = radioByAdjacentText(new RegExp(`(^|[^가-힣])${escapeRegex(targetLabel)}([^가-힣]|$)`, "i"));
      if (!target || !setCheck(target, true)) {
        return { ok: false, code: "A21_TARGET_STATUS_NOT_FOUND", message: `A21 상품판매상태 ${targetLabel} 버튼을 찾지 못했습니다.` };
      }
      if (!target.checked) {
        return { ok: false, code: "A21_STATUS_CONFIGURATION_CHANGED", message: "A21 송신 직전 상품판매상태 설정이 유지되지 않았습니다." };
      }
    }
    if (!mode.checked) {
      return { ok: false, code: "A21_SEND_MODE_CONFIGURATION_CHANGED", message: "A21 송신 직전 선택한 송신 모드가 유지되지 않았습니다." };
    }
    const button = buttonByText(/^상품수정\s*송신$/i);
    if (!button) return { ok: false, code: "A21_SUBMIT_BUTTON_NOT_FOUND", message: "A21 상품수정 송신 버튼을 찾지 못했습니다." };
    const click = await clickViaMain(button);
    const failure = alertFailure(click.alerts);
    if (!click.ok || failure) {
      return { ok: false, code: "A21_SUBMIT_REJECTED", message: failure || click.message || "A21 송신이 거절됐습니다.", evidence: click };
    }
    return {
      ok: true,
      submitted: true,
      step: "A21_POPUP_SUBMITTED",
      message:
        job.productKind === "OPTION"
          ? `A21 goods key ${goodsKey} 옵션송신을 요청했습니다. 최종 완료문구를 기다립니다.`
          : `A21 goods key ${goodsKey} 상품판매상태 ${targetLabel} 송신을 요청했습니다. 최종 완료문구를 기다립니다.`,
      evidence: { goodsKey, mode: job.productKind === "OPTION" ? "OPTION_SEND" : "PRODUCT_SALE_STATUS", targetLabel, alerts: click.alerts },
    };
  }

  function parseCounts(text) {
    const success = [...text.matchAll(/성공건수\s*[:：]?\s*([\d,]+)/gi)].reduce((total, match) => total + Number(match[1].replace(/,/g, "")), 0);
    const failure = [...text.matchAll(/실패건수\s*[:：]?\s*([\d,]+)/gi)].reduce((total, match) => total + Number(match[1].replace(/,/g, "")), 0);
    return { success, failure };
  }

  function resultEvidence() {
    const text = bodyText();
    const counts = parseCounts(text);
    const processing = /처리중입니다/i.test(text) || /잠시만\s*기다려주시기\s*바랍니다/i.test(text);
    const optionComplete =
      /상품\s*옵션\s*(?:수정\s*)?전송이\s*완료되었습니다/i.test(text) ||
      /상품옵션\s*전송이\s*완료되었습니다/i.test(text) ||
      /옵션\s*송신이\s*완료되었습니다/i.test(text);
    const productComplete =
      /상품\s*수정\s*전송이\s*완료되었습니다/i.test(text) ||
      /상품판매상태\s*송신이\s*완료되었습니다/i.test(text);
    const explicitFailure = /성공여부\s*[:：]?\s*실패/i.test(text) || /전송\s*실패|송신\s*실패|처리\s*실패/i.test(text);
    return {
      processing,
      optionComplete,
      productComplete,
      explicitFailure,
      successCount: counts.success,
      failureCount: counts.failure,
      readyState: document.readyState,
      href: String(location.href || ""),
      title: String(document.title || ""),
      textSample: text.slice(-900),
      top: IS_TOP,
    };
  }

  async function publishEvidence() {
    const evidence = resultEvidence();
    if (!evidence.processing && !evidence.optionComplete && !evidence.productComplete && evidence.successCount <= 0 && evidence.failureCount <= 0) return;
    const signature = JSON.stringify({
      processing: evidence.processing,
      optionComplete: evidence.optionComplete,
      productComplete: evidence.productComplete,
      explicitFailure: evidence.explicitFailure,
      successCount: evidence.successCount,
      failureCount: evidence.failureCount,
      href: evidence.href,
      textSample: evidence.textSample,
    });
    if (signature === lastEvidenceSignature) return;
    lastEvidenceSignature = signature;
    await send({ type: "STOCK_SYNC_RESULT_EVIDENCE", evidence });
  }

  function retryable(result) {
    return Boolean(
      result?.navigating ||
        result?.waiting ||
        ["SEARCH_FIELD_NOT_FOUND", "SEARCH_INPUT_NOT_FOUND", "SEARCH_INPUT_SET_FAILED", "SEARCH_BUTTON_NOT_FOUND", "SHOPLING_MENU_NOT_FOUND", "A21_POPUP_WAIT"].includes(String(result?.code || "")),
    );
  }

  async function runStage(stage, job, goodsKey) {
    if (stage === "A6") return runA6(job);
    if (stage === "A4") return runA4(job, goodsKey);
    if (stage === "A21_LIST") return runA21List(job, goodsKey);
    if (stage === "A21_POPUP") return runA21Popup(job, goodsKey);
    return { ok: false, code: "STOCK_SYNC_STAGE_INVALID", message: `지원하지 않는 단계 ${stage}` };
  }

  async function execute(message) {
    const job = message.job || {};    executionContext = { jobId: job.jobId, executionId: job.executionId, stage: message.stage };
    const stage = String(message.stage || "");
    const expectedRole = String(message.expectedRole || "");
    const goodsKey = norm(message.goodsKey);
    const current = role();
    const canNavigate = Boolean(menuTarget(menuPatternFor(stage)));
    if (current !== expectedRole && !canNavigate) {
      return { ok: false, ignored: true, code: "SHOPLING_FRAME_NOT_TARGET", message: `현재 프레임은 ${expectedRole || stage} 실행 대상이 아닙니다.` };
    }
    const key = `${job.jobId || "unknown"}:${job.executionId || ""}:${stage}:${goodsKey}:${location.href}`;
    if (handled.has(key)) return { ok: true, duplicate: true };
    handled.add(key);
    let result;
    try {
      result = await runStage(stage, job, goodsKey);
    } catch (error) {
      result = { ok: false, code: "STOCK_SYNC_CONTENT_EXCEPTION", message: norm(error?.message || error || "Shopling 자동화 예외") };
    }
    if (retryable(result)) handled.delete(key);
    await send({
      type: "STOCK_SYNC_STEP_RESULT",
      jobId: job.jobId,
      stage,
      result,
      page: pageInfo(stage),
    });
    return result;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "STOCK_SYNC_PROBE") {
      sendResponse({ ok: true, page: pageInfo(String(message.stage || "")), version: VERSION });
      return;
    }
    if (message?.type !== "STOCK_SYNC_EXECUTE") return;
    sendResponse({ ok: true, accepted: true, version: VERSION });
    void execute(message).catch(() => null);
    return;
  });

  void send({ type: "STOCK_SYNC_PAGE_READY", page: pageInfo("") });
  void publishEvidence();
  window.setInterval(() => void publishEvidence(), 800);
})();