importScripts("background-v058.js");

// HF17 SINGLE popup claim hardening.
// The popup URL itself is objective evidence that the A21 list worker already opened the
// transmit window. Do not depend on the mutable canonical stage string to authorize the
// dedicated SINGLE sale-status worker. OPTION/HF10 remains untouched.
(() => {
  const VERSION_V059 = chrome.runtime.getManifest().version;
  const SINGLE_CLAIM_V012 = "STOCK_SINGLE_POPUP_CLAIM_V012";
  const POPUP_PATH = "/prodlinkage/goods_mallMdfy_trsmt.phtml";

  function exactPopupUrlV059(url) {
    try {
      const parsed = new URL(String(url || ""));
      return ["https://a.shopling.co.kr", "https://kt.shopling.co.kr"].includes(parsed.origin) && parsed.pathname.toLowerCase() === POPUP_PATH.toLowerCase();
    } catch {
      return false;
    }
  }

  async function exactFreshOwnedSinglePopupV070(active, tabId) {
    const binding = active?.a21PopupOwnershipHf81;
    const listTabId = Number(active?.singleA21ExpectedListTabId || active?.workTabs?.A21_LIST?.tabId);
    const worker = active?.a21ExecutionWorkerHf76;
    const batchQuery = (Array.isArray(active?.singleCurrentBatchKeys) ? active.singleCurrentBatchKeys : [])
      .map((value) => String(value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim())
      .filter(Boolean)
      .join(",");
    const runId = String(active?.job?.executionId || active?.job?.jobId || "");
    const expectedAssignmentOwnerKey = [String(active?.job?.jobId || ""), runId, "SINGLE", batchQuery].join(":");
    if (!Number.isInteger(tabId) || !Number.isInteger(listTabId)) return false;
    if (!binding || binding.productKind !== "SINGLE" || binding.listTabId !== listTabId) return false;
    if (!worker || binding.ownerKey !== worker.ownerKey || Number(worker.tabId) !== listTabId) return false;
    if (!batchQuery || binding.goodsKeyQuery !== batchQuery) return false;
    if (binding.assignmentOwnerKey !== expectedAssignmentOwnerKey) return false;
    if (!["A21_LIST", "A21_POPUP"].includes(String(active?.stage || ""))) return false;
    const claimedTabId = binding.claimedTabId == null ? null : Number(binding.claimedTabId);
    if (active?.stage === "A21_POPUP") {
      return claimedTabId === tabId && Number(active.singlePopupTabId) === tabId;
    }
    if (Number.isInteger(claimedTabId)) return claimedTabId === tabId;
    const baseline = new Set(
      (Array.isArray(binding.baselineTabIds) ? binding.baselineTabIds : [])
        .map(Number)
        .filter(Number.isInteger),
    );
    if (baseline.has(tabId)) return false;
    const candidate = await chrome.tabs.get(tabId).catch(() => null);
    if (!candidate || !exactPopupUrlV059(candidate.url || candidate.pendingUrl)) return false;

    const openerTabId = Number(candidate.openerTabId);
    if (Number.isInteger(openerTabId)) {
      let cursor = openerTabId;
      for (let depth = 0; depth < 6; depth += 1) {
        if (cursor === listTabId) {
          binding.claimedTabId = tabId;
          binding.claimedAt = Date.now();
          return true;
        }
        const opener = await chrome.tabs.get(cursor).catch(() => null);
        if (!opener) return false;
        const next = Number(opener.openerTabId);
        if (!Number.isInteger(next)) return false;
        cursor = next;
      }
      return false;
    }

    const fresh = (await chrome.tabs.query({
      url: [
        "https://a.shopling.co.kr/prodlinkage/goods_mallMdfy_trsmt.phtml*",
        "https://kt.shopling.co.kr/prodlinkage/goods_mallMdfy_trsmt.phtml*",
      ],
    }).catch(() => []))
      .filter((tab) => Number.isInteger(tab?.id) && !baseline.has(Number(tab.id)) && exactPopupUrlV059(tab.url || tab.pendingUrl));
    if (fresh.length !== 1 || Number(fresh[0]?.id) !== tabId) return false;
    binding.claimedTabId = tabId;
    binding.claimedAt = Date.now();
    return true;
  }

  async function claimSinglePopupV059(message, sender) {
    const active = await loadActive();
    if (!active || active.status !== "RUNNING" || active.job?.productKind !== "SINGLE") {
      return { ok: false, error: "stock_single_popup_no_active_job" };
    }

    const tabId = sender?.tab?.id;
    const frameId = Number.isInteger(sender?.frameId) ? sender.frameId : 0;
    const href = String(message?.href || sender?.tab?.url || "");
    if (!Number.isInteger(tabId) || !exactPopupUrlV059(href)) {
      return { ok: false, error: "stock_single_popup_target_mismatch" };
    }
    if (!(await exactFreshOwnedSinglePopupV070(active, tabId))) {
      return { ok: false, error: "stock_single_popup_owner_mismatch_hf70" };
    }

    // Accept only the list->popup transition (or an idempotent re-claim of the same popup).
    // Crucially, do not require singleA21CanonicalStage === POPUP_OPENING because that
    // value is mutable and may be SEARCH_SUBMITTED/retry-derived by the time this document
    // becomes interactive.
    if (!["A21_LIST", "A21_POPUP"].includes(String(active.stage || ""))) {
      return { ok: false, error: "stock_single_popup_not_ready" };
    }
    if (active.stage === "A21_POPUP" && Number.isInteger(active.singlePopupTabId) && active.singlePopupTabId !== tabId) {
      return { ok: false, error: "stock_single_popup_other_window_active" };
    }

    const batchKeys = Array.isArray(active.singleCurrentBatchKeys)
      ? active.singleCurrentBatchKeys.map((value) => norm(value)).filter((value) => /^\d+$/.test(value))
      : [];
    const goodsKey = batchKeys[0] || currentGoodsKey(active);
    if (!goodsKey) return { ok: false, error: "stock_single_popup_goods_key_missing" };

    active.stage = "A21_POPUP";
    active.stageStartedAt = Date.now();
    active.shoplingTabId = tabId;
    active.shoplingFrameId = frameId;
    active.singlePopupTabId = tabId;
    active.singlePopupWindowId = sender?.tab?.windowId ?? null;
    active.workTabs = { ...(active.workTabs || {}), A21_POPUP: { tabId, frameId } };
    await saveActive(active);
    await progress(active, `A21 단품 송신창 연결 · 상품판매상태 ${statusKorean(active.job.desiredStatus)} 정확 선택 worker v012 실행`, {
      popupEngine: "STOCK_SINGLE_SALE_STATUS_V012_EXACT_LOCATOR",
      popupTabId: tabId,
      popupFrameId: frameId,
      canonicalStageAtClaim: active.singleA21CanonicalStage || null,
      batchKeys,
      extensionVersion: VERSION_V059,
    });
    return {
      ok: true,
      assignment: {
        jobId: active.job.jobId,
        goodsKey,
        goodsKeys: batchKeys,
        desiredStatus: active.job.desiredStatus,
      },
      version: VERSION_V059,
    };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type !== SINGLE_CLAIM_V012) return;
    void claimSinglePopupV059(message, sender)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error || "stock_single_popup_claim_v012_failed") }));
    return true;
  });
})();
